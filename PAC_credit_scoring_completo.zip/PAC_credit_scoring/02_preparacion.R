# Lee el archivo original y elimina solo el índice técnico, conservándolo para auditoría.
original <- read.csv('datos/cs-training.csv',check.names=FALSE,na.strings=c('NA',''),stringsAsFactors=FALSE)
stopifnot(ncol(original)==12,all(original[[2]] %in% c(0,1)))
raw <- original[-1]
names(raw) <- c('incumplimiento','utilizacion_rotativa','edad','atrasos_30_59','ratio_deuda',
  'ingreso_mensual','lineas_abiertas','atrasos_90','prestamos_inmobiliarios','atrasos_60_89','dependientes')
raw$.id <- original[[1]]
lag_vars <- c('atrasos_30_59','atrasos_60_89','atrasos_90')
predictor_names <- setdiff(names(raw),c('incumplimiento','.id'))
special_rows <- Reduce(`|`,lapply(raw[lag_vars],function(x) x %in% c(96,98)))
duplicate_rows <- duplicated(raw[setdiff(names(raw),'.id')])
quality_table <- data.frame(
  Problema=c('Incumplimiento observado','Ingreso faltante','Dependientes faltantes','Atrasos 96/98',
   'Utilización > 1','Utilización > 10','Ratio de deuda > 1','Ratio > 1 e ingreso faltante',
   'Edad no válida (0)','Ingreso cero','Duplicados exactos sin índice'),
  Casos=c(sum(raw$incumplimiento),sum(is.na(raw$ingreso_mensual)),sum(is.na(raw$dependientes)),
   sum(special_rows),sum(raw$utilizacion_rotativa>1),sum(raw$utilizacion_rotativa>10),
   sum(raw$ratio_deuda>1),sum(raw$ratio_deuda>1 & is.na(raw$ingreso_mensual)),
   sum(raw$edad==0),sum(raw$ingreso_mensual==0,na.rm=TRUE),sum(duplicate_rows)),
  Decisión=c('Estratificar y evaluar discriminación y calibración','Mediana de entrenamiento + bandera',
   'Moda de entrenamiento + bandera','Tratar como anómalos; NA + bandera; significado no documentado',
   'Mantener indicador de sobregiro; tope p99 para modelo','Tope p99 + log1p',
   'Tope p99 + log1p; no inferir numerador','Examinar junto a bandera; causa no verificada',
   'Excluir registro','Conservar como cero; no equivale a faltante',
   'Excluir copias exactas antes de partición; independencia no demostrable'),check.names=FALSE)
quality_table$Porcentaje <- fmt_pct(quality_table$Casos/nrow(raw),2)
save_tab(quality_table,'t01_calidad','Tabla 1. La calidad de ingresos y atrasos exige tratamiento explícito',
  'Base original; problemas no excluyentes. Los códigos 96/98 se consideran anómalos, sin atribuirles significado administrativo.')
raw_summary <- do.call(rbind,lapply(predictor_names,function(v) {
  x <- raw[[v]]; qs <- quantile(x,c(0,.25,.5,.75,1),na.rm=TRUE)
  data.frame(Variable=v,Observados=sum(!is.na(x)),Faltantes=sum(is.na(x)),
    Mínimo=unname(qs[1]),Q1=unname(qs[2]),Mediana=unname(qs[3]),
    Q3=unname(qs[4]),Máximo=unname(qs[5]),check.names=FALSE)
}))
save_tab(raw_summary,'t05_resumen_original','Las colas extremas difieren ampliamente de los valores centrales',
 'Estadísticos originales antes de cualquier tratamiento; ingreso en u. m., ratios sin unidad, edad en años y otras variables como conteos.')

# Retira copias exactas y la edad cero antes de separar datos, sin aprender parámetros.
clean_raw <- raw[!duplicate_rows,]
n_after_dup <- nrow(clean_raw)
clean_raw <- clean_raw[clean_raw$edad>0,]
rownames(clean_raw) <- NULL
trace_table <- data.frame(Paso=c('Base original','Eliminar duplicados exactos','Excluir edad cero',
  'Imputar y limitar extremos; conservar filas'),
  Afectados=c(0,sum(duplicate_rows),n_after_dup-nrow(clean_raw),NA),
  Resultantes=c(nrow(raw),n_after_dup,nrow(clean_raw),nrow(clean_raw)))
save_tab(trace_table,'t02_trazabilidad','Tabla 2. La depuración elimina únicamente copias exactas y una edad inválida',
 'El último paso conserva observaciones. Los parámetros de tratamiento se estiman exclusivamente en entrenamiento.')

# Divide de forma estratificada, con semilla fija; no usa el conjunto de prueba para seleccionar modelos.
set.seed(2026)
train_index <- unlist(lapply(split(seq_len(nrow(clean_raw)),clean_raw$incumplimiento),
 function(i) sample(i,size=floor(0.70*length(i)))))
train_raw <- clean_raw[train_index,]; test_raw <- clean_raw[-train_index,]

# Aprende únicamente en entrenamiento imputaciones y límites p99; se reutiliza dentro de validación cruzada.
fit_prep <- function(df) {
  z <- df
  for (v in lag_vars) z[[v]][z[[v]] %in% c(96,98)] <- NA_real_
  meds <- vapply(z[c('ingreso_mensual',lag_vars)],median,numeric(1),na.rm=TRUE)
  counts <- table(z$dependientes)
  dep_mode <- as.numeric(names(counts)[which.max(counts)])
  caps <- vapply(z[c('utilizacion_rotativa','ratio_deuda','ingreso_mensual')],
    function(x) as.numeric(quantile(x,0.99,na.rm=TRUE,type=7)),numeric(1))
  list(medians=meds,dep_mode=dep_mode,caps=caps)
}

# Aplica el tratamiento fijo y construye indicadores; los tramos conservan los valores originales.
apply_prep <- function(df,prep) {
  z <- df
  z$ingreso_faltante <- as.integer(is.na(z$ingreso_mensual))
  z$dependientes_faltantes <- as.integer(is.na(z$dependientes))
  z$codigo_especial <- as.integer(Reduce(`|`,lapply(z[lag_vars],function(x) x %in% c(96,98))))
  z$nivel_utilizacion <- cut(z$utilizacion_rotativa,c(-Inf,0.3,0.7,1,Inf),
    labels=c('Baja','Media','Alta','Sobregiro'),right=TRUE)
  # Ajusta explícitamente fronteras: baja <30%; media 30–70%; alta >70–100%.
  z$nivel_utilizacion[z$utilizacion_rotativa==0.3] <- 'Media'
  z$nivel_endeudamiento <- cut(z$ratio_deuda,c(-Inf,0.3,0.6,1,Inf),
    labels=c('≤0,3','>0,3–0,6','>0,6–1','>1'))
  z$tramo_edad <- cut(z$edad,c(-Inf,30,40,50,60,70,Inf),right=FALSE,
    labels=c('<30','30–39','40–49','50–59','60–69','70+'))
  for (v in lag_vars) {
    z[[v]][z[[v]] %in% c(96,98)] <- NA_real_
    z[[v]][is.na(z[[v]])] <- prep$medians[v]
  }
  z$ingreso_mensual[is.na(z$ingreso_mensual)] <- prep$medians['ingreso_mensual']
  z$dependientes[is.na(z$dependientes)] <- prep$dep_mode
  for (v in names(prep$caps)) z[[v]] <- pmin(z[[v]],prep$caps[v])
  z$atrasos_total <- rowSums(z[lag_vars])
  z$alguna_vez_90 <- as.integer(z$atrasos_90>0)
  z$ingreso_per_capita <- z$ingreso_mensual/(z$dependientes+1)
  z$log_utilizacion <- log1p(z$utilizacion_rotativa)
  z$log_deuda <- log1p(z$ratio_deuda)
  z$log_ingreso <- log1p(z$ingreso_mensual)
  z
}
prep <- fit_prep(train_raw)
train <- apply_prep(train_raw,prep); test <- apply_prep(test_raw,prep)
d <- rbind(train,test)
stopifnot(!anyNA(train),!anyNA(test),length(intersect(train$.id,test$.id))==0)
# Cuenta la unión de registros modificados, sin sumar dos veces problemas coincidentes.
before_aligned <- clean_raw[match(d$.id,clean_raw$.id),]
treatment_affected <- Reduce(`|`,lapply(predictor_names,function(v)
  is.na(before_aligned[[v]]) | (!is.na(before_aligned[[v]]) & before_aligned[[v]] != d[[v]])))
trace_table$Afectados[4] <- sum(treatment_affected)
save_tab(trace_table,'t02_trazabilidad','Tabla 2. La depuración conserva las filas con información imputable',
 'El último paso cuenta la unión de registros con al menos una imputación o tope; no elimina filas. Parámetros estimados en entrenamiento.')
split_table <- data.frame(Muestra=c('Entrenamiento','Prueba'),
  n=c(nrow(train),nrow(test)),Incumplimientos=c(sum(train$incumplimiento),sum(test$incumplimiento)),
  Tasa=c(mean(train$incumplimiento),mean(test$incumplimiento)))
save_tab(transform(split_table,Tasa=fmt_pct(Tasa,2)),'t03_particion',
 'Tabla 3. La partición conserva la prevalencia de incumplimiento',
 '70/30 por clase (redondeo entero), semilla 2026; prueba se reserva para evaluación final.')
prep_table <- data.frame(Variable=c(names(prep$medians),'dependientes',names(prep$caps)),
  Parámetro=c(rep('Mediana',length(prep$medians)),'Moda',rep('Percentil 99',length(prep$caps))),
  Valor=c(prep$medians,prep$dep_mode,prep$caps),check.names=FALSE)
save_tab(prep_table,'t04_parametros','Tabla 4. Los parámetros de limpieza se estiman solo en entrenamiento',
 'Ingreso cero se conserva. El percentil 99 usa datos observados de entrenamiento, antes de imputar.')

# Visualiza faltantes y efecto de topes sin ocultar las colas extremas de los datos originales.
miss <- data.frame(Variable=c('Ingreso mensual','Dependientes'),
  Faltantes=c(sum(is.na(raw$ingreso_mensual)),sum(is.na(raw$dependientes))))
p <- ggplot(miss,aes(reorder(Variable,Faltantes),Faltantes,fill=Variable))+
 geom_col(show.legend=FALSE)+coord_flip()+
 geom_text(aes(label=paste0(format(Faltantes,big.mark=' '),' (',fmt_pct(Faltantes/nrow(raw)),')')),hjust=-0.1,size=3.6)+
 scale_y_continuous(expand=expansion(mult=c(0,0.35)))+scale_fill_manual(values=c('#8AA7B8','#356A8A'))+
 labs(x=NULL,y='Registros sin información',subtitle=paste('Base original: n =',format(nrow(raw),big.mark=' ')))
save_fig(p,'f01_faltantes',paste('El ingreso falta en',fmt_pct(mean(is.na(raw$ingreso_mensual))),'de los registros'),
 'Un dato ausente no equivale a ingreso cero; se conserva una bandera indicadora.',height=3)
box_data <- do.call(rbind,lapply(c('utilizacion_rotativa','ratio_deuda','ingreso_mensual'),function(v) {
 data.frame(Variable=v,Etapa=rep(c('Antes','Después'),each=nrow(train)),
  Valor=c(train_raw[[v]],train[[v]]))
}))
box_data$Etapa <- factor(box_data$Etapa,levels=c('Antes','Después'))
p <- ggplot(box_data,aes(Etapa,log1p(Valor),fill=Etapa))+
 geom_boxplot(outlier.size=0.3,outlier.alpha=0.12,na.rm=TRUE)+facet_wrap(~Variable,scales='free_y')+
 scale_fill_manual(values=c('#AEBCC5','#356A8A'))+labs(x=NULL,y='log(1 + valor)',
 subtitle=paste('Entrenamiento: n =',format(nrow(train),big.mark=' ')))+theme(legend.position='none')
save_fig(p,'f02_extremos','El tope p99 reduce las colas sin eliminar clientes',
 'Los ejes usan log(1+x); antes excluye NA de ingreso y después incluye la imputación.',width=9,height=4)

# Resume el flujo metodológico con un diagrama generado y exportado en R.
steps <- data.frame(x=c(1,2,3,4,4,3,2,1),y=c(2,2,2,2,1,1,1,1),
  label=c('Datos originales','Depuración fija','Partición 70/30','Limpieza aprendida\nen entrenamiento',
  'Descriptiva e inferencia\nen entrenamiento','Modelos + diagnósticos','Umbral Youden\nfuera de pliegue','Evaluación final\nen prueba'))
p <- ggplot(steps,aes(x,y))+
 geom_label(aes(label=label),fill='#E9F0F4',color='#19394D',size=3.1,label.padding=grid::unit(.35,'lines'))+
 geom_segment(data=data.frame(x=c(1.35,2.35,3.35,4,3.65,2.65,1.65),xend=c(1.65,2.65,3.65,4,3.35,2.35,1.35),
 y=c(2,2,2,1.8,1,1,1),yend=c(2,2,2,1.2,1,1,1)),aes(x=x,y=y,xend=xend,yend=yend),
 arrow=grid::arrow(length=grid::unit(.12,'inches')),inherit.aes=FALSE)+
 xlim(.45,4.55)+ylim(.5,2.5)+theme_void()
save_fig(p,'f03_flujo','La evaluación final queda separada del desarrollo',
 'En cada pliegue, medianas y percentiles se recalculan usando únicamente su porción de ajuste.',width=10,height=3.5)
saveRDS(list(raw_n=nrow(raw),clean_n=nrow(clean_raw),quality=quality_table,trace=trace_table,
 split=split_table,prep=prep), 'anexos/preparacion_results.rds')
