# Construye objetos compactos para el cuerpo, conservando las tablas completas en anexos.
pr <- readRDS('anexos/preparacion_results.rds')
e <- readRDS('anexos/eda_results.rds')
m <- readRDS('anexos/model_results.rds')
m$metrics_table <- m$metrics
m$metrics <- c(auc=m$auc,auc_low=m$auc_ci[1],auc_high=m$auc_ci[3],gini=m$gini,ks=m$ks,
 accuracy=m$accuracy,sensitivity=m$sensitivity,specificity=m$specificity,
 precision=m$precision,f1=m$f1,brier=m$brier)
publication_main <- e$publication_table[1:12,]
names(publication_main) <- c('Variable','No incumplió','Incumplió','p BH')
inference_main <- e$inference_table[c(1,2,3,4,5,7,9,11,13,15,17,20),c(1,5,6,7)]
names(inference_main) <- c('Variable','p BH','Tamaño del efecto','Magnitud')
comparison_main <- m$comparison[,c('Modelo','Parametros','AIC','BIC','McFadden','AUC_prueba')]
comparison_main$AIC <- fmt_num(comparison_main$AIC,1);comparison_main$BIC <- fmt_num(comparison_main$BIC,1)
comparison_main$McFadden <- fmt_num(comparison_main$McFadden,3)
comparison_main$AUC_prueba <- fmt_num(comparison_main$AUC_prueba,3)
names(comparison_main) <- c('Modelo','Parám.','AIC','BIC','McFadden','AUC prueba')
contrasts_main <- m$contrasts[,c('Contraste','OR','IC95_inf','IC95_sup','p_Wald')]
contrasts_main$`OR [IC 95 %]` <- paste0(fmt_num(contrasts_main$OR),' [',fmt_num(contrasts_main$IC95_inf),'; ',fmt_num(contrasts_main$IC95_sup),']')
contrasts_main$`p Wald` <- fmt_p(contrasts_main$p_Wald)
contrasts_main <- contrasts_main[,c('Contraste','OR [IC 95 %]','p Wald')]
assumptions_main <- data.frame(
  Supuesto=c('Respuesta','Independencia','Forma del logit','Colinealidad','Influencia','Tamaño','Separación','Calibración'),
  Evidencia=c('Binaria 0/1','Duplicados; sin ID real','Box–Tidwell + deciles','VIF / GVIF ajustado',
    'Cook + reestimación','Eventos/parámetro','Convergencia y EE','H–L / Brier / curva'),
  Resultado=c('7 006 eventos en entrenamiento','No demostrable',paste('p',fmt_p(m$bt_p)),
    paste('GVIF ajustado máx.',fmt_num(max(m$vif_final$GVIF_ajustado))),
    paste(m$influence$Casos[1],'casos > 4/n'),paste(fmt_num(m$epv,1),'EPV'),
    'Sin señales numéricas; sin prueba formal',paste('H–L p',fmt_p(m$hl$p))),
  Decisión=c('Usar logística binomial','Supuesto pendiente; validar ID/fechas','Usar splines + log1p',
    'Persistencia en ingreso/ausencia; cautela con OR','Conservar; exclusión sesga clase minoritaria',
    'Supera guía 10; no garantiza validez','Diagnóstico limitado; no certificar ausencia',
    'Discrepancias; validar/recalibrar externamente'),check.names=FALSE)
metrics_main <- data.frame(Métrica=c('AUC [IC 95 %]','Gini / KS','Sensibilidad / especificidad','Precisión / F1','Exactitud / Brier'),
 Resultado=c(paste0(fmt_num(m$auc,3),' [',fmt_num(m$auc_ci[1],3),'; ',fmt_num(m$auc_ci[3],3),']'),
  paste(fmt_num(m$gini,3),fmt_num(m$ks,3),sep=' / '),
  paste(fmt_pct(m$sensitivity),fmt_pct(m$specificity),sep=' / '),
  paste(fmt_pct(m$precision),fmt_num(m$f1,3),sep=' / '),paste(fmt_pct(m$accuracy),fmt_num(m$brier,4),sep=' / ')))
deciles_main <- m$deciles[,c('decil','n','incumplidores','tasa','PD_media','captura_acumulada')]
for (nm in c('tasa','PD_media','captura_acumulada')) deciles_main[[nm]] <- fmt_pct(deciles_main[[nm]],1)
names(deciles_main) <- c('Decil','n','Eventos','Tasa','PD media','Captura acum.')
fig_target <- 'figuras/e01_desbalance.png';fig_key <- 'figuras/e06_panel_hallazgos.png'
fig_predictions <- 'figuras/M02_probabilidades_ajustadas.png'
fig_validation <- 'figuras/M04_discriminacion_confusion.png';fig_gain <- 'figuras/M05_ganancia_calibracion.png'

# Panel compacto con escalas separadas para que la figura sea legible en una página A4.
nr <- e$numeric_results[order(abs(e$numeric_results$efecto),decreasing=TRUE)[1:5],]
cr <- e$categorical_results[order(e$categorical_results$efecto,decreasing=TRUE)[1:5],]
plot_effect <- function(z,title,xlab,col) {
  ggplot(z,aes(efecto,reorder(etiqueta,efecto)))+geom_segment(aes(x=0,xend=efecto,yend=reorder(etiqueta,efecto)),color='#B0BFC7')+
    geom_point(size=2.5,color=col)+geom_text(aes(label=fmt_num(efecto,2)),hjust=-.2,size=3)+
    scale_x_continuous(expand=expansion(mult=c(.05,.25)))+labs(title=title,x=xlab,y=NULL)+
    theme(axis.text.y=element_text(size=8),plot.title=element_text(size=10),axis.title.x=element_text(size=9))
}
p <- plot_effect(nr,'Cinco mayores |δ| numéricos','Delta de Cliff','#B4473D') |
     plot_effect(cr,'Cinco mayores V categóricos','V de Cramér','#356A8A')
save_fig(p,'P01_efectos_resumen','Utilización e historial muestran las mayores asociaciones bivariadas',
 'Entrenamiento; escalas distintas, sin ajuste multivariable. Las tablas completas incluyen las 21 comparaciones.',width=10,height=3.6)
fig_effects <- 'figuras/P01_efectos_resumen.png'

# Contrastes seleccionados para el cuerpo; la figura M01 conserva los trece contrastes.
or_short <- m$contrasts[c(1:7),]
p <- ggplot(or_short,aes(OR,reorder(Contraste,OR)))+geom_vline(xintercept=1,lty=2,color='grey60')+
 geom_errorbar(aes(xmin=IC95_inf,xmax=IC95_sup),orientation='y',width=.2,color='#356A8A')+
 geom_point(color='#356A8A',size=2)+scale_x_log10()+labs(x='OR ajustada (escala logarítmica)',y=NULL)+
 theme(axis.text.y=element_text(size=9))
save_fig(p,'P02_or_resumen','Utilización e historial conservan asociación después del ajuste',
 'Modelo flexible; contrastes de diferente amplitud: no ordenan importancia universal. IC 95 % Wald.',width=9,height=3.5)
fig_or <- 'figuras/P02_or_resumen.png'

# Diccionario y decisiones de indicadores para consulta y auditoría.
dictionary <- data.frame(
 Variable=c('incumplimiento','utilizacion_rotativa','edad','atrasos_30_59 / 60_89 / 90',
  'ratio_deuda','ingreso_mensual','lineas_abiertas','prestamos_inmobiliarios','dependientes',
  'atrasos_total','alguna_vez_90','nivel_utilizacion','nivel_endeudamiento','ingreso_per_capita','tramo_edad',
  'ingreso_faltante / dependientes_faltantes','codigo_especial'),
 Definición=c('Morosidad 90+ días durante dos años siguientes (0/1)','Saldo rotativo / límite (razón)',
  'Edad (años)','Conteos de atrasos por intervalo de duración','Pagos de deuda y gastos / ingreso (razón)',
  'Ingreso mensual (u. m.; moneda no verificada)','Préstamos y líneas abiertas (conteo)',
  'Préstamos inmobiliarios (conteo)','Dependientes excluido el titular (conteo)',
  'Suma de tres conteos depurados; códigos imputados deben identificarse',
  'Atrasos 90+ > 0; categoría separada cuando el historial es especial',
  '<30%, 30–70%, >70–100%, >100%; antes de topar','≤0,3; >0,3–0,6; >0,6–1; >1; antes de topar',
  'Ingreso procesado/(dependientes+1): proxy, no ingreso familiar',
  '<30; 30–39; 40–49; 50–59; 60–69; 70+',
  'Indicador de ausencia original (0/1)','Alguno de los tres atrasos tiene código 96 o 98 (0/1)'),check.names=FALSE)
save_tab(dictionary,'P01_diccionario','Diccionario: unidades y fórmulas se mantienen explícitas',
 'Los tramos son convenciones analíticas, no umbrales regulatorios. El índice original se excluye de los predictores.')
capture.output(sessionInfo(),file='anexos/sessionInfo.txt')
writeLines(paste(names(tools::md5sum('datos/cs-training.csv')),tools::md5sum('datos/cs-training.csv')),
 'anexos/huella_datos_MD5.txt')
saveRDS(list(figures=figure_registry,tables=table_registry),'anexos/registro_sintesis.rds')
if(length(figure_registry)>=18) saveRDS(list(figures=figure_registry,tables=table_registry),
 'anexos/registro_completo.rds')
