# Análisis exploratorio e inferencial: se utiliza exclusivamente entrenamiento.
# Las tasas del conjunto de prueba no se exploran para escoger predictores.
eda_df <- train
eda_df$grupo <- factor(ifelse(eda_df$incumplimiento == 1, "Incumplió", "No incumplió"),
                       levels = c("No incumplió", "Incumplió"))
eda_n <- nrow(eda_df)
eda_prev <- mean(eda_df$incumplimiento)
eda_context <- paste0("Entrenamiento: n = ", fmt_num(eda_n, 0),
                      "; datos de la competencia de 2011; horizonte: dos años")
eda_source <- "Fuente: Kaggle (2011), Give Me Some Credit. Elaboración propia en R."
eda_interpretations <- list()

# Los tramos sintetizan indicadores sin estimar umbrales con la muestra de prueba.
eda_df$tramo_atrasos <- cut(eda_df$atrasos_total,
                          breaks = c(-Inf, 0, 1, 2, Inf),
                          labels = c("Ninguno", "Uno", "Dos", "Tres o más"))
eda_df$tramo_atrasos <- factor(ifelse(eda_df$codigo_especial == 1, "Código especial",
                                      as.character(eda_df$tramo_atrasos)),
                              levels = c("Ninguno", "Uno", "Dos", "Tres o más", "Código especial"))
pc_breaks <- unique(as.numeric(quantile(eda_df$ingreso_per_capita,
                                       probs = seq(0, 1, .25), na.rm = TRUE)))
if (length(pc_breaks) >= 3) {
  pc_breaks[1] <- -Inf
  pc_breaks[length(pc_breaks)] <- Inf
  eda_df$tramo_ingreso_pc <- cut(eda_df$ingreso_per_capita, breaks = pc_breaks,
                                labels = paste0("Q", seq_len(length(pc_breaks) - 1)),
                                include.lowest = TRUE)
} else {
  eda_df$tramo_ingreso_pc <- factor("Sin variación suficiente")
}
binary_indicator <- function(x) factor(ifelse(x == 1, "Sí", "No"), levels = c("No", "Sí"))
eda_df$alguna_vez_90_cat <- binary_indicator(eda_df$alguna_vez_90)
eda_df$alguna_vez_90_cat <- factor(ifelse(eda_df$codigo_especial == 1, "Código especial",
                                         as.character(eda_df$alguna_vez_90_cat)),
                                 levels = c("No", "Sí", "Código especial"))
eda_df$ingreso_faltante_cat <- binary_indicator(eda_df$ingreso_faltante)
eda_df$dependientes_faltantes_cat <- binary_indicator(eda_df$dependientes_faltantes)
eda_df$codigo_especial_cat <- binary_indicator(eda_df$codigo_especial)

eda_num_labels <- c(utilizacion_rotativa = "Utilización rotativa (razón)",
                    edad = "Edad (años)", atrasos_30_59 = "Atrasos de 30–59 días (n)",
                    ratio_deuda = "Ratio de deuda (razón)",
                    ingreso_mensual = "Ingreso mensual (u. m.)",
                    lineas_abiertas = "Líneas de crédito abiertas (n)",
                    atrasos_90 = "Atrasos de 90+ días (n)",
                    prestamos_inmobiliarios = "Préstamos inmobiliarios (n)",
                    atrasos_60_89 = "Atrasos de 60–89 días (n)",
                    dependientes = "Dependientes (n)",
                    atrasos_total = "Atrasos totales (n)",
                    ingreso_per_capita = "Ingreso por persona, proxy (u. m.)")
eda_cat_labels <- c(tramo_atrasos = "Atrasos totales",
                    alguna_vez_90_cat = "Algún atraso de 90+ días",
                    nivel_utilizacion = "Nivel de utilización",
                    nivel_endeudamiento = "Nivel de endeudamiento",
                    tramo_ingreso_pc = "Ingreso por persona, proxy (cuartil)",
                    tramo_edad = "Edad (tramo en años)",
                    ingreso_faltante_cat = "Ingreso originalmente faltante",
                    codigo_especial_cat = "Código especial 96/98",
                    dependientes_faltantes_cat = "Dependientes originalmente faltantes")

# El intervalo de Wilson evita límites negativos en categorías poco frecuentes.
wilson95 <- function(k, n) {
  z <- qnorm(.975)
  rate <- k / n
  centre <- (rate + z^2 / (2 * n)) / (1 + z^2 / n)
  half <- z * sqrt(rate * (1 - rate) / n + z^2 / (4 * n^2)) / (1 + z^2 / n)
  data.frame(tasa = rate, inferior = pmax(0, centre - half), superior = pmin(1, centre + half))
}
indicator_rates <- do.call(rbind, lapply(names(eda_cat_labels), function(v) {
  lev <- levels(factor(eda_df[[v]]))
  if (is.factor(eda_df[[v]])) lev <- levels(eda_df[[v]])
  n <- vapply(lev, function(k) sum(eda_df[[v]] == k, na.rm = TRUE), numeric(1))
  events <- vapply(lev, function(k) sum(eda_df$incumplimiento[which(eda_df[[v]] == k)]), numeric(1))
  out <- data.frame(variable = v, indicador = unname(eda_cat_labels[v]),
                    categoria = lev, orden = seq_along(lev), n = n, incumplidores = events)
  cbind(out, wilson95(events, n))
}))
rownames(indicator_rates) <- NULL
rates_public <- indicator_rates |>
  dplyr::transmute(Indicador = indicador, Categoría = categoria,
                   Clientes = n, Incumplidores = incumplidores,
                   `Tasa (%)` = fmt_pct(tasa),
                   `IC 95 %` = paste0(fmt_pct(inferior), "–", fmt_pct(superior)))
save_tab(rates_public, "e01_tasas_indicadores",
         "La frecuencia de incumplimiento cambia entre los tramos de los indicadores",
         paste0("Entrenamiento. IC de Wilson; referencia global: ", fmt_pct(eda_prev),
                ". Cuartiles de ingreso por persona estimados solo con entrenamiento. u. m. = unidades monetarias; moneda no verificada."))
pc_cut_table <- data.frame(Percentil = c("P0", "P25", "P50", "P75", "P100"),
                           `Ingreso por persona (u. m.)` = as.numeric(quantile(eda_df$ingreso_per_capita,
                                 probs = seq(0, 1, .25), na.rm = TRUE)), check.names = FALSE)
save_tab(pc_cut_table, "e02_cortes_ingreso_persona", "Los cuartiles fijan la comparación de ingreso por persona",
         "Límites estimados en entrenamiento tras imputar y tratar extremos; los cuartiles son descriptivos.")

# Las barras muestran la prevalencia y la cantidad de clientes en cada clase.
target_tab <- as.data.frame(table(eda_df$grupo))
names(target_tab) <- c("grupo", "n")
target_tab$proporcion <- target_tab$n / sum(target_tab$n)
target_tab$label <- paste0(fmt_pct(target_tab$proporcion), "\nn = ", fmt_num(target_tab$n, 0))
target_title <- paste0("Solo ", fmt_pct(eda_prev), " de los clientes de entrenamiento incumple")
p_target <- ggplot2::ggplot(target_tab, ggplot2::aes(grupo, proporcion, fill = grupo)) +
  ggplot2::geom_col(width = .58) +
  ggplot2::geom_text(ggplot2::aes(label = label), vjust = -.35, size = 4) +
  ggplot2::scale_fill_manual(values = pal) +
  ggplot2::scale_y_continuous(labels = scales::label_percent(decimal.mark = ",", big.mark = " "),
                            limits = c(0, 1.06), expand = ggplot2::expansion(mult = c(0, .02))) +
  ggplot2::labs(title = target_title, subtitle = eda_context, x = NULL,
                y = "Proporción de clientes", caption = eda_source) +
  ggplot2::theme(legend.position = "none")
save_fig(p_target, "e01_desbalance", target_title,
         "La baja frecuencia del evento exige evaluar sensibilidad y AUC además de exactitud.", width = 7, height = 4.3)
eda_interpretations$e01_desbalance <- paste0("En entrenamiento hay ",
  fmt_num(sum(eda_df$incumplimiento), 0), " incumplidores y ",
  fmt_num(sum(1 - eda_df$incumplimiento), 0),
  " clientes sin incumplimiento. Una clasificación sistemática como no incumplidor tendría una exactitud de ",
  fmt_pct(1 - eda_prev), ", pero sensibilidad nula.")

# Cada panel conserva denominadores, tasa de referencia e incertidumbre del indicador.
rate_panel <- function(v, compact = FALSE, points = FALSE) {
  z <- indicator_rates[indicator_rates$variable == v, ]
  z$categoria <- factor(z$categoria, levels = z$categoria)
  display_categories <- vapply(as.character(z$categoria), function(x)
    paste(strwrap(x, width = 11), collapse = "\n"), character(1))
  axis_labels <- setNames(paste0(display_categories, "\nn=", fmt_num(z$n, 0)), z$categoria)
  ggplot2::ggplot(z, ggplot2::aes(categoria, tasa)) +
    ggplot2::geom_hline(yintercept = eda_prev, linetype = "dashed", color = "#555555", linewidth = .45) +
    (if (points) ggplot2::geom_point(color = unname(pal["Incumplió"]), size = 2.5)
     else ggplot2::geom_col(fill = unname(pal["Incumplió"]), width = .58, alpha = .88)) +
    ggplot2::geom_errorbar(ggplot2::aes(ymin = inferior, ymax = superior), width = .14, linewidth = .4) +
    ggplot2::geom_text(ggplot2::aes(y = superior, label = fmt_pct(tasa)),
                       vjust = -.55, size = if (compact) 2.8 else 3.2) +
    ggplot2::scale_x_discrete(labels = axis_labels) +
    ggplot2::scale_y_continuous(labels = scales::label_percent(accuracy = 1, decimal.mark = ",", big.mark = " "),
                               limits = c(0, min(1, max(z$superior) * 1.27)),
                               expand = ggplot2::expansion(mult = c(0, .02))) +
    ggplot2::labs(title = unname(eda_cat_labels[v]), x = NULL,
                  y = "Incumplimiento en dos años") +
    ggplot2::theme(axis.text.x = ggplot2::element_text(size = if (compact) 7.4 else 8.4),
                   axis.text.y = ggplot2::element_text(size = 8),
                   axis.title.y = ggplot2::element_text(size = 9),
                   plot.title = ggplot2::element_text(size = 11, face = "bold"))
}
util_rates <- indicator_rates[indicator_rates$variable == "nivel_utilizacion", ]
credit_title <- paste0("La mayor tasa por utilización llega a ", fmt_pct(max(util_rates$tasa)))
p_credit_rates <- patchwork::wrap_plots(lapply(names(eda_cat_labels)[1:4], rate_panel), ncol = 2) +
  patchwork::plot_annotation(title = credit_title, subtitle = eda_context,
    caption = paste0("Línea discontinua: tasa global (", fmt_pct(eda_prev),
                     "). Barras de error: IC 95 % de Wilson.\n", eda_source))
save_fig(p_credit_rates, "e02_tasas_crediticias", credit_title,
         paste0("IC 95 % de Wilson; línea = tasa global (", fmt_pct(eda_prev),
                "). Asociaciones sin ajustar; 96/98 se separan de los atrasos reales."),
         width = 8.3, height = 7)
top_util <- util_rates[which.max(util_rates$tasa), ]
low_util <- util_rates[which.min(util_rates$tasa), ]
eda_interpretations$e02_tasas_crediticias <- paste0("El tramo ", top_util$categoria,
  " presenta una tasa de ", fmt_pct(top_util$tasa), " (n = ", fmt_num(top_util$n, 0),
  "), frente a ", fmt_pct(low_util$tasa), " en el tramo ", low_util$categoria,
  ". La comparación es descriptiva y no atribuye causalidad a la utilización.")
age_rates <- indicator_rates[indicator_rates$variable == "tramo_edad", ]
age_title <- paste0("El incumplimiento va de ", fmt_pct(min(age_rates$tasa)), " a ",
                    fmt_pct(max(age_rates$tasa)), " entre tramos de edad")
p_social_rates <- patchwork::wrap_plots(lapply(names(eda_cat_labels)[5:9], rate_panel, compact = TRUE), ncol = 2) +
  patchwork::plot_annotation(title = age_title, subtitle = eda_context,
    caption = paste0("Línea discontinua: tasa global (", fmt_pct(eda_prev),
                     "). IC 95 % de Wilson. Q1–Q4: cuartiles de ingreso por persona.\n", eda_source))
save_fig(p_social_rates, "e03_tasas_demograficas", age_title,
         paste0("IC 95 % de Wilson; línea = ", fmt_pct(eda_prev),
                ". Q1–Q4: ingreso por persona imputado/topado; la imputación no equivale a observación."),
         width = 8.3, height = 10)
special_rates <- indicator_rates[indicator_rates$variable == "codigo_especial_cat", ]
eda_interpretations$e03_tasas_demograficas <- paste0("Los tramos de edad presentan tasas entre ",
  fmt_pct(min(age_rates$tasa)), " y ", fmt_pct(max(age_rates$tasa)),
  ". Los registros con código especial tienen una tasa de ",
  fmt_pct(special_rates$tasa[special_rates$categoria == "Sí"]),
  "; este indicador informa sobre el registro de datos y exige validar su significado operativo.")

# Las distribuciones complementan las medianas; log1p reduce la compresión por asimetría.
distribution_vars <- c("utilizacion_rotativa", "edad", "ratio_deuda", "ingreso_mensual")
dist_data <- eda_df[, c("grupo", distribution_vars)] |>
  tidyr::pivot_longer(-grupo, names_to = "variable", values_to = "valor") |>
  dplyr::mutate(valor_grafico = ifelse(variable == "edad", valor, log1p(valor)),
    panel = dplyr::case_when(variable == "edad" ~ "Edad (años)",
                            variable == "utilizacion_rotativa" ~ "Utilización rotativa: log(1 + razón)",
                            variable == "ratio_deuda" ~ "Ratio de deuda: log(1 + razón)",
                            TRUE ~ "Ingreso mensual: log(1 + u. m.)"))
age_median <- tapply(eda_df$edad, eda_df$grupo, median)
dist_title <- paste0("La edad mediana es ", fmt_num(age_median["Incumplió"], 0),
                     " años entre incumplidores y ", fmt_num(age_median["No incumplió"], 0), " entre los demás")
p_dist <- ggplot2::ggplot(dist_data, ggplot2::aes(grupo, valor_grafico, fill = grupo)) +
  ggplot2::geom_violin(trim = TRUE, alpha = .55, scale = "width", linewidth = .25) +
  ggplot2::geom_boxplot(width = .13, outlier.shape = NA, fill = "white", linewidth = .35) +
  ggplot2::facet_wrap(~panel, scales = "free_y", ncol = 2) +
  ggplot2::scale_fill_manual(values = pal) +
  ggplot2::labs(title = dist_title, subtitle = eda_context, x = NULL,
                y = "Valor observado o transformado (según panel)", caption = eda_source) +
  ggplot2::theme(legend.position = "none", axis.text.x = ggplot2::element_text(size = 9))
save_fig(p_dist, "e04_distribuciones", dist_title,
         "Caja: mediana y cuartiles. Densidades normalizadas por grupo; los picos reflejan también imputaciones y topes.",
         width = 8.3, height = 6.7)
eda_interpretations$e04_distribuciones <- paste0("La mediana de edad es ",
  fmt_num(age_median["Incumplió"], 0), " años entre incumplidores y ",
  fmt_num(age_median["No incumplió"], 0),
  " entre no incumplidores. La superposición de las distribuciones muestra que ninguna variable aislada separa por completo a los grupos.")

# Spearman es robusto a escala; Pearson muestra la distorsión de conteos 96/98.
late_vars <- c("atrasos_30_59", "atrasos_60_89", "atrasos_90")
late_names <- c("30–59 días", "60–89 días", "90+ días")
any_special <- Reduce(`|`, lapply(train_raw[late_vars], function(x) x %in% c(96, 98)))
corr_data <- do.call(rbind, lapply(c("spearman", "pearson"), function(method) {
  do.call(rbind, lapply(c(FALSE, TRUE), function(remove_special) {
    zz <- if (remove_special) train_raw[!any_special, late_vars] else train_raw[late_vars]
    cm <- cor(zz, use = "pairwise.complete.obs", method = method)
    out <- as.data.frame(as.table(cm), stringsAsFactors = FALSE)
    names(out) <- c("fila", "columna", "correlacion")
    out$metodo <- if (method == "spearman") "Spearman" else "Pearson"
    out$tratamiento <- if (remove_special) "Sin registros con códigos 96/98" else "Con códigos 96/98"
    out
  }))
}))
corr_data$fila <- factor(corr_data$fila, levels = late_vars, labels = late_names)
corr_data$columna <- factor(corr_data$columna, levels = late_vars, labels = late_names)
corr_data$tratamiento <- factor(corr_data$tratamiento,
                                levels = c("Con códigos 96/98", "Sin registros con códigos 96/98"))
corr_data$metodo <- factor(corr_data$metodo, levels = c("Spearman", "Pearson"))
corr_pairs <- corr_data[as.integer(corr_data$fila) > as.integer(corr_data$columna), ]
pearson_before <- corr_pairs$correlacion[corr_pairs$metodo == "Pearson" & corr_pairs$tratamiento == "Con códigos 96/98"]
pearson_after <- corr_pairs$correlacion[corr_pairs$metodo == "Pearson" & corr_pairs$tratamiento == "Sin registros con códigos 96/98"]
corr_title <- paste0("Los códigos elevan la correlación de Pearson hasta ", fmt_num(max(pearson_before)))
p_corr <- ggplot2::ggplot(corr_data, ggplot2::aes(columna, fila, fill = correlacion)) +
  ggplot2::geom_tile(color = "white", linewidth = 1) +
  ggplot2::geom_text(ggplot2::aes(label = fmt_num(correlacion)), size = 3.5, color = "#1D2933") +
  ggplot2::facet_grid(metodo ~ tratamiento) +
  ggplot2::scale_fill_gradient2(low = "#B4473D", mid = "#F4F4F1", high = "#6E9CB3",
                                midpoint = 0, limits = c(-1, 1), name = "Correlación") +
  ggplot2::labs(title = corr_title, subtitle = eda_context, x = NULL, y = NULL, caption = eda_source) +
  ggplot2::theme(axis.text = ggplot2::element_text(size = 9), legend.position = "bottom")
save_fig(p_corr, "e05_correlaciones", corr_title,
         "La comparación excluye solo códigos para aislar su efecto; Spearman usa rangos y es menos sensible a su magnitud.",
         width = 8.3, height = 6.5)
eda_interpretations$e05_correlaciones <- paste0("Con los códigos 96/98, Pearson entre atrasos varía de ",
  fmt_num(min(pearson_before)), " a ", fmt_num(max(pearson_before)),
  "; al excluirlos, de ", fmt_num(min(pearson_after)), " a ", fmt_num(max(pearson_after)),
  ". Spearman no reproduce necesariamente esa caída porque depende de rangos, no de la magnitud de los códigos.")

# Un panel reutilizable condensa cuatro asociaciones para la presentación oral.
p_four <- patchwork::wrap_plots(lapply(c("nivel_utilizacion", "tramo_atrasos", "tramo_edad", "codigo_especial_cat"),
                                     rate_panel, compact = TRUE, points = TRUE), ncol = 2) +
  patchwork::plot_annotation(title = "Utilización, atrasos, edad y códigos especiales distinguen perfiles de riesgo",
    subtitle = eda_context,
    caption = paste0("Asociaciones sin ajuste; línea = tasa global; IC 95 % de Wilson.\n", eda_source))
save_fig(p_four, "e06_panel_hallazgos", "Cuatro indicadores distinguen perfiles con distinta frecuencia de incumplimiento",
         paste0("IC 95 % de Wilson; línea = ", fmt_pct(eda_prev),
                ". Comparar tasas junto con sus denominadores; las asociaciones no establecen causas."), width = 8.3, height = 7)
eda_interpretations$e06_panel_hallazgos <- "Las diferencias de tasas permiten identificar perfiles para seguimiento. El ajuste multivariable debe comprobar qué asociaciones persisten al considerar simultáneamente los demás predictores."

# Mann–Whitney compara distribuciones; delta de Cliff cuantifica su separación.
# El signo positivo significa valores mayores entre incumplidores; no implica causalidad.
numeric_results <- do.call(rbind, lapply(names(eda_num_labels), function(v) {
  x1 <- eda_df[[v]][eda_df$incumplimiento == 1]
  x0 <- eda_df[[v]][eda_df$incumplimiento == 0]
  x1 <- x1[is.finite(x1)]
  x0 <- x0[is.finite(x0)]
  wt <- wilcox.test(x1, x0, exact = FALSE, correct = TRUE)
  delta <- 2 * unname(wt$statistic) / (length(x1) * length(x0)) - 1
  magnitude <- cut(abs(delta), breaks = c(-Inf, .147, .33, .474, Inf),
                   labels = c("Despreciable", "Pequeña", "Mediana", "Grande"), right = FALSE)
  data.frame(variable = v, etiqueta = unname(eda_num_labels[v]), prueba = "U de Mann–Whitney",
              estadistico = unname(wt$statistic), p = wt$p.value, efecto = delta,
              tipo_efecto = "Delta de Cliff", magnitud = as.character(magnitude),
              n = length(x1) + length(x0), min_esperada = NA_real_)
}))

# Chi-cuadrado evalúa asociación; V de Cramér expresa magnitud sin dirección.
chi_residuals <- list()
categorical_results <- do.call(rbind, lapply(names(eda_cat_labels), function(v) {
  tab <- table(eda_df[[v]], eda_df$grupo)
  base_test <- suppressWarnings(chisq.test(tab, correct = FALSE))
  small_expected <- any(base_test$expected < 5)
  ct <- if (small_expected) chisq.test(tab, correct = FALSE, simulate.p.value = TRUE, B = 9999) else base_test
  cv <- sqrt(unname(base_test$statistic) / (sum(tab) * min(nrow(tab) - 1, ncol(tab) - 1)))
  magnitude <- cut(cv, breaks = c(-Inf, .1, .3, .5, Inf),
                   labels = c("Despreciable", "Pequeña", "Mediana", "Grande"), right = FALSE)
  rr <- as.data.frame(as.table(base_test$stdres), stringsAsFactors = FALSE)
  names(rr) <- c("categoria", "grupo", "residuo")
  rr$variable <- v
  rr$indicador <- unname(eda_cat_labels[v])
  chi_residuals[[v]] <<- rr
  data.frame(variable = v, etiqueta = unname(eda_cat_labels[v]),
              prueba = if (small_expected) "Chi² (Monte Carlo)" else "Chi² de independencia",
              estadistico = unname(base_test$statistic), p = ct$p.value, efecto = cv,
              tipo_efecto = "V de Cramér", magnitud = as.character(magnitude),
              n = sum(tab), min_esperada = min(base_test$expected))
}))

# Una familia de 21 contrastes exploratorios se ajusta conjuntamente por BH.
inference_raw <- rbind(numeric_results, categorical_results)
inference_raw$p_bh <- p.adjust(inference_raw$p, method = "BH")
numeric_results$p_bh <- inference_raw$p_bh[match(numeric_results$variable, inference_raw$variable)]
categorical_results$p_bh <- inference_raw$p_bh[match(categorical_results$variable, inference_raw$variable)]
inference_table <- inference_raw |>
  dplyr::transmute(Variable = etiqueta, Prueba = prueba,
                   Estadístico = fmt_num(estadistico), `p sin ajuste` = fmt_p(p),
                   `p ajustado (BH)` = fmt_p(p_bh),
                   `Tamaño del efecto` = paste0(tipo_efecto, ": ", fmt_num(efecto, 3)),
                   Magnitud = magnitud, `¿Significativa?` = ifelse(p_bh < .05, "Sí", "No"))
save_tab(inference_table, "e03_inferencia", "La magnitud del efecto distingue asociaciones más allá de la significancia",
         paste0("Entrenamiento; α = 0,05; BH sobre ", nrow(inference_raw),
                " contrastes. Magnitudes orientativas: |δ| 0,147/0,33/0,474 y V 0,10/0,30/0,50. No comparar las escalas δ y V como si fueran iguales."))

# La tabla de publicación contiene medianas [Q1; Q3] y n (%) por resultado.
iqr_text <- function(x) {
  q <- quantile(x, c(.25, .5, .75), na.rm = TRUE)
  paste0(fmt_num(q[2]), " [", fmt_num(q[1]), "; ", fmt_num(q[3]), "]")
}
pub_num <- do.call(rbind, lapply(names(eda_num_labels), function(v) {
  data.frame(Variable = unname(eda_num_labels[v]),
              no = iqr_text(eda_df[[v]][eda_df$incumplimiento == 0]),
              si = iqr_text(eda_df[[v]][eda_df$incumplimiento == 1]),
              p = fmt_p(numeric_results$p_bh[numeric_results$variable == v]), check.names = FALSE)
}))
pub_cat <- do.call(rbind, lapply(names(eda_cat_labels), function(v) {
  tt <- table(eda_df[[v]], eda_df$grupo)
  rows <- data.frame(Variable = paste0("  ", rownames(tt)),
    no = paste0(fmt_num(tt[, 1], 0), " (", fmt_pct(tt[, 1] / sum(tt[, 1])), ")"),
    si = paste0(fmt_num(tt[, 2], 0), " (", fmt_pct(tt[, 2] / sum(tt[, 2])), ")"),
    p = "", check.names = FALSE)
  rbind(data.frame(Variable = unname(eda_cat_labels[v]), no = "", si = "",
                   p = fmt_p(categorical_results$p_bh[categorical_results$variable == v]), check.names = FALSE), rows)
}))
publication_table <- rbind(pub_num, pub_cat)
names(publication_table) <- c("Variable",
  paste0("No incumplió (n = ", fmt_num(sum(eda_df$incumplimiento == 0), 0), ")"),
  paste0("Incumplió (n = ", fmt_num(sum(eda_df$incumplimiento == 1), 0), ")"), "p ajustado (BH)")
save_tab(publication_table, "e04_perfil_publicacion", "Los perfiles difieren en posición y composición entre clases",
         "Entrenamiento. Numéricas: mediana [Q1; Q3]; categóricas: n (% dentro de la clase). U de Mann–Whitney y chi-cuadrado; BH sobre toda la familia exploratoria. u. m.: unidades monetarias de moneda no verificada.")

# La normalidad se contrasta dentro de cada clase, no sobre una mezcla de ambas.
# AD es muy sensible con n grande y sus p son aproximados con conteos o empates.
normal_specs <- data.frame(variable = c("edad", "utilizacion_rotativa", "ratio_deuda", "ingreso_mensual",
                                        "utilizacion_rotativa", "ratio_deuda", "ingreso_mensual"),
                           transformacion = c(rep("Original tratada", 4), rep("log1p", 3)), stringsAsFactors = FALSE)
normality_raw <- do.call(rbind, lapply(seq_len(nrow(normal_specs)), function(i) {
  sp <- normal_specs[i, ]
  do.call(rbind, lapply(levels(eda_df$grupo), function(g) {
    x <- eda_df[[sp$variable]][eda_df$grupo == g]
    if (sp$transformacion == "log1p") x <- log1p(x)
    x <- x[is.finite(x)]
    ad <- nortest::ad.test(x)
    data.frame(variable = sp$variable, etiqueta = unname(eda_num_labels[sp$variable]),
                transformacion = sp$transformacion, grupo = g, n = length(x),
                A = unname(ad$statistic), p = ad$p.value,
                fraccion_empates = 1 - length(unique(x)) / length(x))
  }))
}))
normality_table <- normality_raw |>
  dplyr::transmute(Variable = etiqueta, Transformación = transformacion, Grupo = grupo,
                   n = n, `A²` = fmt_num(A), `p AD` = fmt_p(p),
                   `% de repeticiones` = fmt_pct(fraccion_empates))
save_tab(normality_table, "e05_normalidad", "La normalidad no describe adecuadamente todas las distribuciones por clase",
         "Anderson–Darling por clase. Sus p son sensibles al tamaño y solo orientativos ante empates/discreción. Q-Q y asimetría respaldan pruebas no paramétricas. La logística no requiere normalidad de predictores.")
qq_data <- do.call(rbind, lapply(c("utilizacion_rotativa", "ratio_deuda", "ingreso_mensual"), function(v) {
  do.call(rbind, lapply(c(FALSE, TRUE), function(use_log) {
    do.call(rbind, lapply(levels(eda_df$grupo), function(g) {
      x <- eda_df[[v]][eda_df$grupo == g]
      if (use_log) x <- log1p(x)
      probs <- seq(.005, .995, length.out = 199)
      data.frame(teorico = qnorm(probs),
        observado = (as.numeric(quantile(x, probs, na.rm = TRUE)) - mean(x)) / sd(x), grupo = g,
        variable = unname(eda_num_labels[v]),
        transformacion = if (use_log) "log1p" else "Original tratada")
    }))
  }))
}))
qq_data$transformacion <- factor(qq_data$transformacion, levels = c("Original tratada", "log1p"))
qq_title <- paste0("Anderson–Darling rechaza normalidad en ", sum(normality_raw$p < .05),
                   " de ", nrow(normality_raw), " comparaciones por clase")
p_qq <- ggplot2::ggplot(qq_data, ggplot2::aes(teorico, observado, color = grupo)) +
  ggplot2::geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "#666666") +
  ggplot2::geom_line(linewidth = .6) +
  ggplot2::facet_grid(variable ~ transformacion, scales = "free_y") +
  ggplot2::scale_color_manual(values = pal) +
  ggplot2::labs(title = qq_title, subtitle = eda_context,
                x = "Cuantiles teóricos de N(0,1)", y = "Cuantiles observados estandarizados",
                color = NULL, caption = eda_source) +
  ggplot2::theme(legend.position = "bottom", strip.text.y = ggplot2::element_text(size = 8))
save_fig(p_qq, "e07_qq_normalidad", qq_title,
         "Cuantiles 0,5 %–99,5 % calculados sobre todos los registros de cada clase. La recta representa normalidad; la logística no la exige.",
         width = 8.3, height = 7.5)
eda_interpretations$e07_qq_normalidad <- paste0("Se rechaza normalidad en ",
  sum(normality_raw$p < .05), " de ", nrow(normality_raw),
  " contrastes. Los gráficos muestran desviaciones de la recta incluso tras transformar; se reportan medianas y pruebas por rangos, sin exigir normalidad para la regresión logística.")

# Las escalas de Cliff y Cramér se presentan separadas para no equiparar sus magnitudes.
cliff_plot <- numeric_results[order(abs(numeric_results$efecto)), ]
cliff_plot$etiqueta <- factor(cliff_plot$etiqueta, levels = cliff_plot$etiqueta)
cramer_plot <- categorical_results[order(categorical_results$efecto), ]
cramer_plot$etiqueta <- factor(cramer_plot$etiqueta, levels = cramer_plot$etiqueta)
p_cliff <- ggplot2::ggplot(cliff_plot, ggplot2::aes(efecto, etiqueta)) +
  ggplot2::geom_vline(xintercept = 0, color = "#777777", linetype = "dashed") +
  ggplot2::geom_segment(ggplot2::aes(x = 0, xend = efecto, yend = etiqueta), color = "#A8B7C0") +
  ggplot2::geom_point(size = 2.7, color = unname(pal["Incumplió"])) +
  ggplot2::geom_text(ggplot2::aes(label = fmt_num(efecto, 3)), hjust = -.25, size = 2.9) +
  ggplot2::scale_x_continuous(limits = c(min(-.1, min(cliff_plot$efecto) - .08), max(cliff_plot$efecto) + .14)) +
  ggplot2::labs(title = "Variables numéricas: delta de Cliff", x = "δ (positivo: valores mayores al incumplir)", y = NULL) +
  ggplot2::theme(axis.text.y = ggplot2::element_text(size = 8), plot.title = ggplot2::element_text(size = 11),
                 axis.title.x = ggplot2::element_text(size = 9))
p_cramer <- ggplot2::ggplot(cramer_plot, ggplot2::aes(efecto, etiqueta)) +
  ggplot2::geom_segment(ggplot2::aes(x = 0, xend = efecto, yend = etiqueta), color = "#A8B7C0") +
  ggplot2::geom_point(size = 2.7, color = unname(pal["No incumplió"])) +
  ggplot2::geom_text(ggplot2::aes(label = fmt_num(efecto, 3)), hjust = -.25, size = 2.9) +
  ggplot2::scale_x_continuous(limits = c(0, max(cramer_plot$efecto) + .12)) +
  ggplot2::labs(title = "Indicadores categóricos: V de Cramér", x = "V (sin dirección)", y = NULL) +
  ggplot2::theme(axis.text.y = ggplot2::element_text(size = 8), plot.title = ggplot2::element_text(size = 11),
                 axis.title.x = ggplot2::element_text(size = 9))
effect_title <- paste0(sum(inference_raw$p_bh < .05), " de ", nrow(inference_raw),
                       " asociaciones son significativas; su magnitud es desigual")
p_effect <- patchwork::wrap_plots(p_cliff, p_cramer, ncol = 1, heights = c(1.15, 1)) +
  patchwork::plot_annotation(title = effect_title, subtitle = eda_context,
                              caption = paste0("Orden por magnitud dentro de cada escala. Ajuste BH; asociaciones sin ajuste multivariable.\n", eda_source))
save_fig(p_effect, "e08_tamanos_efecto", effect_title,
         "No comparar directamente delta de Cliff con V de Cramér; significancia estadística no equivale a utilidad predictiva.",
         width = 8.3, height = 9.5)
top_numeric <- numeric_results[which.max(abs(numeric_results$efecto)), ]
top_categorical <- categorical_results[which.max(categorical_results$efecto), ]
eda_interpretations$e08_tamanos_efecto <- paste0("La mayor separación numérica corresponde a ",
  top_numeric$etiqueta, " (δ = ", fmt_num(top_numeric$efecto, 3), "). Entre indicadores categóricos destaca ",
  top_categorical$etiqueta, " (V = ", fmt_num(top_categorical$efecto, 3),
  "). Son análisis bivariados; las escalas tienen definiciones diferentes y no se ordenan conjuntamente.")

# Los residuos muestran las celdas que explican la asociación del chi-cuadrado.
chi_residuals_df <- do.call(rbind, chi_residuals)
res_plot <- chi_residuals_df[chi_residuals_df$variable %in%
                             c("nivel_utilizacion", "tramo_atrasos", "tramo_edad", "codigo_especial_cat"), ]
res_plot$grupo <- factor(res_plot$grupo, levels = c("No incumplió", "Incumplió"))
res_plot$celda <- paste0(res_plot$indicador, ": ", res_plot$categoria)
res_plot$celda <- factor(res_plot$celda, levels = rev(unique(res_plot$celda)))
res_limit <- max(abs(res_plot$residuo))
res_title <- "Los residuos localizan excesos y déficits de incumplimiento por categoría"
p_resid <- ggplot2::ggplot(res_plot, ggplot2::aes(grupo, celda, fill = residuo)) +
  ggplot2::geom_tile(color = "white", linewidth = .8) +
  ggplot2::geom_text(ggplot2::aes(label = fmt_num(residuo, 1)), size = 3.3) +
  ggplot2::scale_fill_gradient2(low = "#8CAFC2", mid = "#F4F4F1", high = "#D9958D",
                                midpoint = 0, limits = c(-res_limit, res_limit), name = "Residuo\nestandarizado") +
  ggplot2::labs(title = res_title, subtitle = eda_context, x = NULL, y = NULL, caption = eda_source) +
  ggplot2::theme(axis.text.y = ggplot2::element_text(size = 8.5), legend.position = "right")
save_fig(p_resid, "e09_residuos_chi", res_title,
         "Positivo: más clientes que lo esperado bajo independencia; negativo: menos. Es un diagnóstico descriptivo, sin pruebas por celda.",
         width = 8.3, height = 7)
eda_interpretations$e09_residuos_chi <- "Las celdas positivas contienen más observaciones de las esperadas si el indicador fuera independiente del incumplimiento. La magnitud de los residuos crece con el tamaño de muestra y no sustituye a V de Cramér como tamaño del efecto."

# Se conservan resultados numéricos para redactar automáticamente sin inventar cifras.
eda_results <- list(n = eda_n, prevalence = eda_prev, target = target_tab,
  indicator_rates = indicator_rates, pc_cut_table = pc_cut_table,
  numeric_results = numeric_results, categorical_results = categorical_results,
  inference_raw = inference_raw, inference_table = inference_table,
  publication_table = publication_table, normality_raw = normality_raw,
  normality_table = normality_table, correlation_data = corr_data,
  correlation_pairs = corr_pairs, chi_residuals = chi_residuals_df,
  interpretations = eda_interpretations,
  methodological_notes = c(
    "Exploración e inferencia realizadas únicamente en entrenamiento.",
    "La tasa global y todos los hallazgos se calculan; no se fijan a valores anticipados del enunciado.",
    "MW contrasta distribuciones; la interpretación exclusiva como diferencia de medianas requiere formas similares.",
    "Los contrastes usan datos imputados: no propagan incertidumbre de la imputación; análisis exploratorio.",
    "La independencia entre clientes no puede garantizarse sin identificadores personales verificables.",
    "Las tasas por tramos y los contrastes bivariados no tienen interpretación causal.",
    "La normalidad de predictores no es un supuesto de la regresión logística."
  ))
saveRDS(eda_results, file.path("anexos", "eda_results.rds"))
writeLines(unlist(Map(function(id, txt) paste0(id, ": ", txt),
                      names(eda_interpretations), eda_interpretations)),
           file.path("anexos", "interpretaciones_eda.txt"), useBytes = TRUE)
