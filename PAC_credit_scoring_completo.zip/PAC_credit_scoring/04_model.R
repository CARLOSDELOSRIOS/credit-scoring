# Regresión logística: selección en entrenamiento y prueba reservada.
# Todos los umbrales de limpieza se estiman sin utilizar la muestra de prueba.
stopifnot(all(train$incumplimiento %in% c(0, 1)),
          all(test$incumplimiento %in% c(0, 1)))
set.seed(2026)
model_labels <- c(log_utilizacion = "Utilización rotativa (log1p)", edad = "Edad (años)",
  atrasos_30_59 = "Atrasos de 30–59 días", log_deuda = "Ratio de deuda (log1p)",
  log_ingreso = "Ingreso mensual (log1p)", lineas_abiertas = "Líneas abiertas",
  atrasos_90 = "Atrasos de 90+ días", prestamos_inmobiliarios = "Préstamos inmobiliarios",
  atrasos_60_89 = "Atrasos de 60–89 días", dependientes = "Dependientes",
  ingreso_faltante = "Ingreso faltante", dependientes_faltantes = "Dependientes faltantes",
  codigo_especial = "Código especial 96/98")
form_full <- incumplimiento ~ log_utilizacion + edad + atrasos_30_59 + log_deuda +
  log_ingreso + lineas_abiertas + atrasos_90 + prestamos_inmobiliarios +
  atrasos_60_89 + dependientes + ingreso_faltante + dependientes_faltantes + codigo_especial
# La reducida conserva variables sustantivas de capacidad, exposición e historial.
form_reduced <- incumplimiento ~ log_utilizacion + edad + atrasos_30_59 +
  log_deuda + log_ingreso + atrasos_90 + atrasos_60_89 + dependientes +
  ingreso_faltante + codigo_especial
# La flexible permite curvatura y rendimientos decrecientes de los conteos.
form_flexible <- incumplimiento ~ splines::ns(log_utilizacion, df = 4) +
  splines::ns(edad, df = 4) + log1p(atrasos_30_59) +
  splines::ns(log_deuda, df = 4) + splines::ns(log_ingreso, df = 4) +
  log1p(lineas_abiertas) + log1p(atrasos_90) + log1p(prestamos_inmobiliarios) +
  log1p(atrasos_60_89) + dependientes + ingreso_faltante +
  dependientes_faltantes + codigo_especial
formulas <- list(Completo = form_full, Reducido = form_reduced, Flexible = form_flexible)
fits <- lapply(formulas, function(f) glm(f, data = train, family = binomial()))
fit_null <- glm(incumplimiento ~ 1, data = train, family = binomial())
train_aic <- vapply(fits, AIC, numeric(1))
chosen_name <- names(which.min(train_aic))
fit_final <- fits[[chosen_name]]
chosen_formula <- formulas[[chosen_name]]
message("Especificación congelada por AIC de entrenamiento: ", chosen_name)

# Cinco folds estratificados: cada fold vuelve a ajustar medianas y topes.
# OOF se condiciona a la fórmula ya seleccionada: no es CV anidada del proceso.
set.seed(2026)
fold_id <- integer(nrow(train_raw))
for (g in 0:1) {
  ii <- which(train_raw$incumplimiento == g)
  fold_id[ii] <- sample(rep(1:5, length.out = length(ii)))
}
oof <- rep(NA_real_, nrow(train_raw))
for (k in 1:5) {
  local_prep <- fit_prep(train_raw[fold_id != k, , drop = FALSE])
  local_train <- apply_prep(train_raw[fold_id != k, , drop = FALSE], local_prep)
  local_valid <- apply_prep(train_raw[fold_id == k, , drop = FALSE], local_prep)
  local_fit <- glm(chosen_formula, data = local_train, family = binomial())
  oof[fold_id == k] <- predict(local_fit, newdata = local_valid, type = "response")
  message("Validación OOF: fold ", k, "/5 completo")
}
roc_oof <- pROC::roc(train_raw$incumplimiento, oof, levels = c(0, 1),
                     direction = "<", quiet = TRUE)
best_oof <- as.data.frame(pROC::coords(roc_oof, x = "best", best.method = "youden",
  ret = c("threshold", "sensitivity", "specificity"), transpose = FALSE))
# En empates se prefiere el umbral mayor; la regla se fija antes de abrir prueba.
threshold <- max(best_oof$threshold[is.finite(best_oof$threshold)])
stopifnot(is.finite(threshold), all(is.finite(oof)))
pred_test <- as.numeric(predict(fit_final, newdata = test, type = "response"))
pred_train <- as.numeric(predict(fit_final, type = "response"))
y_test <- test$incumplimiento
roc_test <- pROC::roc(y_test, pred_test, levels = c(0, 1), direction = "<", quiet = TRUE)
auc_test <- as.numeric(pROC::auc(roc_test))
auc_ci <- as.numeric(pROC::ci.auc(roc_test, method = "delong"))
gini_test <- 2 * auc_test - 1
ks_test <- max(roc_test$sensitivities + roc_test$specificities - 1)
class_test <- as.integer(pred_test >= threshold)
TP <- sum(class_test == 1 & y_test == 1); TN <- sum(class_test == 0 & y_test == 0)
FP <- sum(class_test == 1 & y_test == 0); FN <- sum(class_test == 0 & y_test == 1)
safe_div <- function(a, b) ifelse(b > 0, a / b, NA_real_)
accuracy <- (TP + TN) / length(y_test)
sensitivity <- safe_div(TP, TP + FN); specificity <- safe_div(TN, TN + FP)
precision <- safe_div(TP, TP + FP); f1 <- safe_div(2 * TP, 2 * TP + FP + FN)
brier <- mean((y_test - pred_test)^2)
baseline_brier <- mean((y_test - mean(train$incumplimiento))^2)
clip_prob <- function(p) pmin(pmax(p, 1e-8), 1 - 1e-8)
cal_data <- data.frame(y = y_test, lp = qlogis(clip_prob(pred_test)))
cal_fit <- glm(y ~ lp, data = cal_data, family = binomial())
cal_intercept_fit <- glm(y ~ 1 + offset(lp), data = cal_data, family = binomial())
cal_intercept <- unname(coef(cal_intercept_fit)[1])
cal_slope <- unname(coef(cal_fit)["lp"])
comparison <- data.frame(Modelo = names(fits),
  Parametros = vapply(fits, function(m) length(coef(m)), integer(1)),
  AIC = vapply(fits, AIC, numeric(1)), BIC = vapply(fits, BIC, numeric(1)),
  McFadden = vapply(fits, function(m) 1 - as.numeric(logLik(m))/as.numeric(logLik(fit_null)), numeric(1)),
  AUC_prueba = vapply(fits, function(m) as.numeric(pROC::auc(pROC::roc(y_test,
    as.numeric(predict(m, newdata = test, type = "response")), levels = c(0, 1),
    direction = "<", quiet = TRUE))), numeric(1)),
  Seleccion = ifelse(names(fits) == chosen_name, "Menor AIC de entrenamiento", "Comparador"))
save_tab(comparison, "M01_comparacion_modelos",
  paste0("La especificación ", tolower(chosen_name), " minimiza el AIC de entrenamiento"),
  "AUC de prueba es descriptiva posterior: no intervino en selección. Parámetros incluyen intercepto.")
metrics <- data.frame(Metrica = c("n prueba", "Eventos prueba", "Umbral Youden OOF",
  "AUC", "AUC IC95% inferior", "AUC IC95% superior", "Gini", "KS", "Exactitud",
  "Sensibilidad", "Especificidad", "Precisión (VPP)", "F1", "Brier", "Brier nulo",
  "Intercepto calibración (ideal 0)", "Pendiente calibración (ideal 1)",
  "AUC OOF entrenamiento", "Proporción clasificada alto riesgo"),
  Valor = c(length(y_test), sum(y_test), threshold, auc_test, auc_ci[1], auc_ci[3],
    gini_test, ks_test, accuracy, sensitivity, specificity, precision, f1, brier,
    baseline_brier, cal_intercept, cal_slope, as.numeric(pROC::auc(roc_oof)), mean(class_test)))
save_tab(metrics, "M02_metricas_prueba",
  paste0("El modelo separa los grupos con AUC = ", fmt_num(auc_test, 3)),
  "Métricas de prueba calculadas en muestra reservada; AUC OOF y umbral proceden de entrenamiento. OOF no anidada, condicionada a la fórmula seleccionada.")

# Coeficientes y OR del comparador lineal: las bases spline no son efectos unitarios.
or_linear <- broom::tidy(fits$Completo) |>
  dplyr::mutate(OR = exp(estimate), IC95_inf = exp(estimate - 1.96 * std.error),
    IC95_sup = exp(estimate + 1.96 * std.error),
    Variable = unname(model_labels[term]),
    Interpretacion = dplyr::case_when(term == "(Intercept)" ~ "Odds del perfil de referencia matemático.",
      grepl("^log_", term) ~ paste0("Multiplicar (1 + X) por e multiplica las odds por ", fmt_num(OR), "."),
      term %in% c("ingreso_faltante", "dependientes_faltantes", "codigo_especial") ~
        paste0("Bandera presente frente a ausente: odds × ", fmt_num(OR), ", ajustadas."),
      TRUE ~ paste0("Una unidad adicional: odds × ", fmt_num(OR), ", manteniendo las demás variables.")))
or_linear$Variable[or_linear$term == "(Intercept)"] <- "Intercepto"
save_tab(or_linear[, c("Variable", "OR", "IC95_inf", "IC95_sup", "p.value", "Interpretacion")], "M03_OR_comparador_lineal",
  "Los OR unitarios describen el comparador lineal y requieren cautela por la curvatura",
  "IC95% Wald. Estos OR no sustituyen los contrastes del modelo final flexible; odds no equivale a probabilidad.")

# Perfil de referencia construido sólo con medianas y banderas de entrenamiento.
profile <- train[1, , drop = FALSE]
for (nm in names(profile)) {
  if (is.numeric(train[[nm]])) profile[[nm]] <- median(train[[nm]], na.rm = TRUE)
}
profile$ingreso_faltante <- 0; profile$dependientes_faltantes <- 0
profile$codigo_especial <- 0
profile$atrasos_30_59 <- 0; profile$atrasos_60_89 <- 0; profile$atrasos_90 <- 0
contrast_spec <- data.frame(variable = c("log_utilizacion", "edad", "atrasos_30_59", "atrasos_60_89",
  "atrasos_90", "log_deuda", "log_ingreso", "lineas_abiertas", "prestamos_inmobiliarios",
  "dependientes", "ingreso_faltante", "dependientes_faltantes", "codigo_especial"),
  desde = c(log1p(.10), 40, 0, 0, 0, log1p(.20), log1p(3000), 5, 0, 0, 0, 0, 0),
  hasta = c(log1p(.90), 60, 1, 1, 1, log1p(.80), log1p(8000), 10, 1, 1, 1, 1, 1),
  Contraste = c("Utilización: 10% → 90%", "Edad: 40 → 60 años", "Atrasos 30–59: 0 → 1",
    "Atrasos 60–89: 0 → 1", "Atrasos 90+: 0 → 1", "Ratio deuda: 0,20 → 0,80",
    "Ingreso: 3.000 → 8.000 unidades", "Líneas abiertas: 5 → 10",
    "Préstamos inmobiliarios: 0 → 1", "Dependientes: 0 → 1", "Ingreso faltante: no → sí",
    "Dependientes faltantes: no → sí", "Código 96/98: no → sí"))
model_contrasts <- function(m) {
  out <- lapply(seq_len(nrow(contrast_spec)), function(i) {
    lo <- hi <- profile
    lo[[contrast_spec$variable[i]]] <- contrast_spec$desde[i]
    hi[[contrast_spec$variable[i]]] <- contrast_spec$hasta[i]
    mm <- model.matrix(delete.response(terms(m)), rbind(lo, hi), contrasts.arg = m$contrasts,
                       xlev = m$xlevels)
    delta <- mm[2, ] - mm[1, ]
    beta <- coef(m); active <- !is.na(beta)
    # Una sensibilidad puede vaciar categorías; no propagar un NA a todo contraste.
    estimable <- all(abs(delta[!active]) < 1e-10)
    v <- vcov(m)[active, active, drop = FALSE]
    est <- if (estimable) as.numeric(delta[active] %*% beta[active]) else NA_real_
    se <- if (estimable) sqrt(as.numeric(delta[active] %*% v %*% delta[active])) else NA_real_
    data.frame(Variable = contrast_spec$variable[i], Contraste = contrast_spec$Contraste[i],
      log_OR = est, EE = se, OR = exp(est), IC95_inf = exp(est - 1.96 * se),
      IC95_sup = exp(est + 1.96 * se), p_Wald = 2 * pnorm(-abs(est / se)),
      Prob_desde = if (estimable) as.numeric(predict(m, lo, type = "response")) else NA_real_,
      Prob_hasta = if (estimable) as.numeric(predict(m, hi, type = "response")) else NA_real_)
  })
  dplyr::bind_rows(out)
}
or_contrasts <- model_contrasts(fit_final)
or_contrasts$Interpretacion <- paste0("El cambio señalado multiplica las odds ajustadas por ",
  fmt_num(or_contrasts$OR), "; asociación condicional, no causal.")
save_tab(or_contrasts[, c("Contraste", "OR", "IC95_inf", "IC95_sup", "p_Wald", "Interpretacion")], "M04_OR_contrastes_modelo_final",
  "El historial de pagos y la utilización aportan asociaciones ajustadas relevantes",
  "Contrastes específicos, no coeficientes de bases spline. IC95% Wald; ingreso en unidades monetarias originales no verificadas.")
p_or <- ggplot2::ggplot(or_contrasts,
  ggplot2::aes(x = OR, y = reorder(Contraste, OR))) +
  ggplot2::geom_vline(xintercept = 1, linetype = 2, colour = "grey45") +
  ggplot2::geom_errorbar(ggplot2::aes(xmin = IC95_inf, xmax = IC95_sup), width = .18,
    orientation = "y", colour = "#356A8A") +
  ggplot2::geom_point(size = 2.6, colour = "#356A8A") +
  ggplot2::scale_x_log10() + ggplot2::labs(x = "Odds ratio ajustado (escala logarítmica)", y = NULL,
    subtitle = paste0("Modelo ", tolower(chosen_name), "; entrenamiento n = ", nrow(train)))
save_fig(p_or, "M01_forest_OR", "El historial de atrasos eleva las odds de incumplimiento",
  "Cada punto compara los valores indicados; las barras son IC95%. OR no es riesgo relativo ni causalidad.", height = 5.0)

# Probabilidades condicionales: el perfil se mantiene fijo, no son efectos causales.
effect_spec <- list(
  list(v = "log_utilizacion", x = seq(0, min(1.5, max(train$utilizacion_rotativa)), length.out = 90), lab = "Utilización rotativa (ratio)", log = TRUE),
  list(v = "edad", x = seq(21, 90, length.out = 90), lab = "Edad (años)", log = FALSE),
  list(v = "atrasos_90", x = 0:6, lab = "Atrasos de 90+ días (veces)", log = FALSE),
  list(v = "log_ingreso", x = seq(0, 20000, length.out = 90), lab = "Ingreso mensual (unidades originales)", log = TRUE))
effects <- dplyr::bind_rows(lapply(effect_spec, function(s) {
  nd <- profile[rep(1, length(s$x)), , drop = FALSE]
  nd[[s$v]] <- if (s$log) log1p(s$x) else s$x
  pr <- predict(fit_final, newdata = nd, type = "link", se.fit = TRUE)
  data.frame(x = s$x, prob = plogis(pr$fit), inferior = plogis(pr$fit - 1.96 * pr$se.fit),
    superior = plogis(pr$fit + 1.96 * pr$se.fit), Variable = s$lab)
}))
p_effects <- ggplot2::ggplot(effects, ggplot2::aes(x, prob)) +
  ggplot2::geom_ribbon(ggplot2::aes(ymin = inferior, ymax = superior), fill = "#356A8A", alpha = .18) +
  ggplot2::geom_line(colour = "#356A8A", linewidth = .8) +
  ggplot2::facet_wrap(~ Variable, scales = "free_x", ncol = 2) +
  ggplot2::scale_x_continuous(breaks = scales::breaks_pretty(n = 3),
    labels = scales::label_number(big.mark = " ", decimal.mark = ",")) +
  ggplot2::scale_y_continuous(labels = scales::label_percent(decimal.mark = ",")) +
  ggplot2::labs(x = "Valor de la variable indicada en cada panel", y = "Probabilidad predicha",
    subtitle = paste0("Perfil de medianas, sin atrasos ni banderas; entrenamiento n = ", nrow(train))) +
  ggplot2::theme(panel.spacing.x=grid::unit(1.7,"lines"),axis.text.x=ggplot2::element_text(size=9))
save_fig(p_effects, "M02_probabilidades_ajustadas", "La relación entre perfil y riesgo presenta curvatura",
  "Bandas IC95% del promedio condicional. Las demás variables permanecen fijas; no son efectos causales.", height = 5.0)

# Box–Tidwell sobre cuatro predictores continuos del comparador lineal.
bt_data <- train
bt_variables <- c("log_utilizacion", "edad", "log_deuda", "log_ingreso")
for (v in bt_variables) bt_data[[paste0("BT_", v)]] <- (bt_data[[v]] + 1) * log(bt_data[[v]] + 1)
bt_formula <- update(form_full, . ~ . + BT_log_utilizacion + BT_edad + BT_log_deuda + BT_log_ingreso)
bt_fit <- glm(bt_formula, data = bt_data, family = binomial())
bt_table <- broom::tidy(bt_fit) |>
  dplyr::filter(grepl("^BT_", term)) |>
  dplyr::mutate(p_Holm = p.adjust(p.value, method = "holm"),
    Variable = unname(model_labels[sub("BT_", "", term)]))
bt_lrt <- anova(fits$Completo, bt_fit, test = "LRT")
bt_global_p <- bt_lrt$`Pr(>Chi)`[2]
save_tab(bt_table[, c("Variable", "estimate", "std.error", "statistic", "p.value", "p_Holm")], "M05_Box_Tidwell", "La linealidad del logit se evalúa antes de adoptar splines",
  "Prueba X·log(X) con desplazamiento +1, sobre escalas ya log1p salvo edad; ajuste Holm. No certifica cualquier forma funcional.")

# VIF del mismo comparador con conteos especiales intactos y depurados.
raw_vif_data <- train
for (v in c("atrasos_30_59", "atrasos_60_89", "atrasos_90")) raw_vif_data[[v]] <- train_raw[[v]]
fit_raw_vif <- glm(form_full, data = raw_vif_data, family = binomial())
to_vif <- function(m) {
  z <- car::vif(m)
  if (is.matrix(z)) data.frame(Variable = rownames(z), VIF = z[, "GVIF"],
    Df = z[, "Df"], GVIF_ajustado = z[, "GVIF"]^(1/(2 * z[, "Df"]))) else
      data.frame(Variable = names(z), VIF = as.numeric(z), Df = 1,
        GVIF_ajustado = sqrt(as.numeric(z)))
}
vif_raw <- to_vif(fit_raw_vif); vif_clean <- to_vif(fits$Completo)
vif_table <- merge(vif_raw[, c("Variable", "VIF")], vif_clean[, c("Variable", "VIF")],
  by = "Variable", suffixes = c("_con_codigos", "_sin_codigos"))
save_tab(vif_table, "M06_VIF_codigos", "Los códigos 96/98 alteran la colinealidad de los atrasos",
  "Mismo modelo lineal y muestra de entrenamiento; sólo se restituyen los conteos 96/98. VIF > 5 requiere revisión.")
vif_final <- to_vif(fit_final)
save_tab(vif_final, "M07_GVIF_final", "El GVIF del modelo flexible considera los grados de libertad",
  "Para términos con varios parámetros usar GVIF^(1/(2·Df)); el umbral comparable a VIF 5 es raíz(5), no 5.")

# Contraste global, EPV y separación: convergencia no prueba su ausencia.
lrt_global <- anova(fit_null, fit_final, test = "LRT")
lrt_stat <- lrt_global$Deviance[2]; lrt_df <- lrt_global$Df[2]
lrt_p <- lrt_global$`Pr(>Chi)`[2]
n_parameters <- length(coef(fit_final)) - 1
epv <- sum(train$incumplimiento) / n_parameters
coef_final <- broom::tidy(fit_final)
save_tab(coef_final, "M08_coeficientes_tecnicos", "Las pruebas de Wald corresponden a parámetros de la especificación final",
  "Los coeficientes de bases spline deben interpretarse conjuntamente; los contrastes de M04 son interpretables.")
separation_note <- paste0("glm converge: ", fit_final$converged,
  "; coeficientes/EE finitos: ", all(is.finite(coef_final$estimate) & is.finite(coef_final$std.error)),
  "; máximo |coeficiente| = ", fmt_num(max(abs(coef_final$estimate))),
  "; máximo EE = ", fmt_num(max(coef_final$std.error)), ".")
formal_separation <- NA
if (requireNamespace("detectseparation", quietly = TRUE)) {
  sep_fit <- tryCatch(glm(chosen_formula, data = train, family = binomial(),
    method = detectseparation::detect_separation), error = function(e) NULL)
  if (!is.null(sep_fit)) formal_separation <- any(is.infinite(coef(sep_fit)))
}

# Influencia: se conserva la muestra principal; excluir no convierte un dato en error.
cook <- cooks.distance(fit_final); leverage <- hatvalues(fit_final)
std_resid <- rstandard(fit_final, type = "deviance")
cook_cut <- 4 / nrow(train); leverage_cut <- 2 * length(coef(fit_final)) / nrow(train)
influential <- which(cook > cook_cut)
influence_table <- data.frame(Criterio = c("Cook > 4/n", "Leverage > 2p/n", "|Residuo desvío estandarizado| > 3"),
  Casos = c(length(influential), sum(leverage > leverage_cut), sum(abs(std_resid) > 3)),
  Umbral = c(cook_cut, leverage_cut, 3))
save_tab(influence_table, "M09_influencia", "La influencia requiere análisis de sensibilidad, no exclusión automática",
  "Los tres criterios son pantallas diagnósticas y pueden señalar observaciones válidas de la clase minoritaria.")
fit_sensitivity <- glm(chosen_formula, data = train[-influential, , drop = FALSE], family = binomial())
sens_or <- model_contrasts(fit_sensitivity)
sensitivity_contrasts <- merge(or_contrasts[, c("Variable", "Contraste", "OR")],
  sens_or[, c("Variable", "OR")], by = "Variable", suffixes = c("_principal", "_sin_influyentes"))
sensitivity_contrasts$Cambio_relativo_OR <- sensitivity_contrasts$OR_sin_influyentes /
  sensitivity_contrasts$OR_principal - 1
sensitivity_mm <- model.matrix(delete.response(terms(fit_sensitivity)), train,
  contrasts.arg = fit_sensitivity$contrasts, xlev = fit_sensitivity$xlevels)
sensitivity_aliased <- is.na(coef(fit_sensitivity))
sensitivity_estimable <- if (any(sensitivity_aliased))
  rowSums(abs(sensitivity_mm[, sensitivity_aliased, drop = FALSE])) < 1e-10 else rep(TRUE, nrow(train))
sensitivity_pred <- rep(NA_real_, nrow(train))
sensitivity_pred[sensitivity_estimable] <- as.numeric(predict(fit_sensitivity,
  newdata = train[sensitivity_estimable, , drop = FALSE], type = "response"))
sensitivity_mae <- mean(abs(sensitivity_pred - pred_train), na.rm = TRUE)
sensitivity_event_share <- sum(train$incumplimiento[influential]) / sum(train$incumplimiento)
save_tab(sensitivity_contrasts, "M10_sensibilidad_influencia", "Excluir observaciones influyentes modifica asociaciones y composición de la muestra",
  paste0("Se excluyen ", length(influential), " casos que representan ", fmt_pct(sensitivity_event_share),
    " de los eventos; no se adopta esta exclusión. Diferencia absoluta media de PD: ", fmt_num(sensitivity_mae, 4),
    " en ", sum(sensitivity_estimable), " perfiles estimables. NA: categoría desaparecida; ajuste excluido genera probabilidades extremas."))

# Sensibilidad acotada: excluir los diez casos de mayor Cook evita confundir
# estabilidad ante casos individuales con retirar casi toda la clase minoritaria.
top_influential <- order(cook, decreasing = TRUE)[seq_len(min(10, length(cook)))]
fit_top10 <- glm(chosen_formula, data = train[-top_influential, , drop = FALSE], family = binomial())
top10_or <- model_contrasts(fit_top10)
top10_contrasts <- merge(or_contrasts[, c("Variable", "Contraste", "OR")],
  top10_or[, c("Variable", "OR")], by = "Variable", suffixes = c("_principal", "_sin_top10"))
top10_contrasts$Cambio_relativo_OR <- top10_contrasts$OR_sin_top10 / top10_contrasts$OR_principal - 1
top10_mae <- mean(abs(as.numeric(predict(fit_top10, newdata = train, type = "response")) - pred_train))
save_tab(top10_contrasts, "M16_sensibilidad_top10", "La reestimación sin los diez casos más influyentes cuantifica la estabilidad local",
  paste0("Criterio top10 Cook fijado como sensibilidad diagnóstica; diferencia absoluta media de PD = ",
    fmt_num(top10_mae, 6), ". No se usa prueba ni se reemplaza el modelo principal."))

# H–L implementado por deciles de probabilidad, con esperados de ambas clases.
hosmer_lemeshow <- function(y, p, g = 10) {
  cuts <- unique(stats::quantile(p, probs = seq(0, 1, length.out = g + 1), type = 7))
  group <- cut(p, breaks = cuts, include.lowest = TRUE)
  dat <- data.frame(y = y, p = p, group = group) |>
    dplyr::group_by(group) |>
    dplyr::summarise(n = dplyr::n(), observados = sum(y), esperados = sum(p),
      probabilidad = mean(p), tasa = mean(y), .groups = "drop")
  statistic <- sum((dat$observados - dat$esperados)^2 *
    (1 / dat$esperados + 1 / (dat$n - dat$esperados)))
  df <- nrow(dat) - 2
  list(statistic = statistic, df = df, p = pchisq(statistic, df, lower.tail = FALSE), table = dat)
}
hl <- hosmer_lemeshow(y_test, pred_test)
save_tab(hl$table, "M11_calibracion_deciles", "La calibración compara probabilidades estimadas con frecuencias observadas",
  paste0("Prueba n = ", length(y_test), "; H–L = ", fmt_num(hl$statistic), ", gl = ", hl$df,
    ", p ", ifelse(hl$p < .001, "< 0,001", paste0("= ", fmt_num(hl$p, 3))),
    ". Referencia convencional g−2 exploratoria en prueba; priorizar gráfico, Brier, intercepto y pendiente."))

# Logit empírico por deciles: evidencia exploratoria, no comparación causal.
empirical_logit <- dplyr::bind_rows(lapply(c("log_utilizacion", "edad", "log_deuda", "log_ingreso"), function(v) {
  z <- data.frame(x = train[[v]], y = train$incumplimiento)
  z$grupo <- dplyr::ntile(z$x, 10)
  z |>
    dplyr::group_by(grupo) |>
    dplyr::summarise(x = mean(x), n = dplyr::n(), eventos = sum(y),
      logit = log((eventos + .5)/(n - eventos + .5)), .groups = "drop") |>
    dplyr::mutate(Variable = unname(model_labels[v]))
}))
p_emp <- ggplot2::ggplot(empirical_logit, ggplot2::aes(x, logit)) +
  ggplot2::geom_line(colour = "#356A8A") + ggplot2::geom_point(colour = "#356A8A", size = 1.8) +
  ggplot2::geom_smooth(method = "lm", se = FALSE, colour = "#B4473D", linetype = 2, linewidth = .5) +
  ggplot2::facet_wrap(~ Variable, scales = "free_x", ncol = 2) +
  ggplot2::labs(x = "Media por decil de cada predictor", y = "Logit empírico del incumplimiento",
    subtitle = paste0("Entrenamiento n = ", nrow(train), "; línea discontinua: tendencia lineal"))
save_fig(p_emp, "M03_logit_empirico", "La curvatura del logit justifica evaluar una especificación flexible",
  "Deciles marginales con corrección 0,5; empates pueden dividirse. El patrón marginal no demuestra el ajuste condicional.", height = 5.0)

# Un panel reúne separación, discriminación y decisiones con el umbral prefijado.
roc_df <- data.frame(FPR = 1 - roc_test$specificities, TPR = roc_test$sensitivities)
p_roc <- ggplot2::ggplot(roc_df, ggplot2::aes(FPR, TPR)) +
  ggplot2::geom_abline(linetype = 2, colour = "grey65") +
  ggplot2::geom_path(colour = "#356A8A", linewidth = .9) +
  ggplot2::scale_x_continuous(labels = scales::label_percent()) +
  ggplot2::scale_y_continuous(labels = scales::label_percent()) +
  ggplot2::labs(title = paste0("AUC = ", fmt_num(auc_test, 3)),
    subtitle = paste0("IC95% ", fmt_num(auc_ci[1], 3), "–", fmt_num(auc_ci[3], 3)),
    x = "1 − especificidad", y = "Sensibilidad")
ks_grid <- sort(unique(c(seq(0, 1, length.out = 600), quantile(pred_test, seq(0, 1, .01)))))
ks_df <- rbind(data.frame(PD = ks_grid, F = ecdf(pred_test[y_test == 0])(ks_grid), Grupo = "No incumplió"),
               data.frame(PD = ks_grid, F = ecdf(pred_test[y_test == 1])(ks_grid), Grupo = "Incumplió"))
p_ks <- ggplot2::ggplot(ks_df, ggplot2::aes(PD, F, colour = Grupo)) +
  ggplot2::geom_line(linewidth = .8) +
  ggplot2::scale_colour_manual(values = c("No incumplió" = "#356A8A", "Incumplió" = "#B4473D")) +
  ggplot2::scale_x_continuous(labels = scales::label_percent()) +
  ggplot2::scale_y_continuous(labels = scales::label_percent()) +
  ggplot2::labs(title = paste0("KS = ", fmt_pct(ks_test)), x = "Probabilidad estimada", y = "Distribución acumulada", colour = NULL) +
  ggplot2::theme(legend.position = "bottom")
confusion <- data.frame(Real = rep(c("No incumplió", "Incumplió"), each = 2),
  Prediccion = rep(c("Bajo riesgo", "Alto riesgo"), 2), n = c(TN, FP, FN, TP),
  Etiqueta = c("VN", "FP", "FN", "VP"))
confusion$Texto <- paste0(confusion$Etiqueta, "\n", format(confusion$n, big.mark = ".", scientific = FALSE, trim = TRUE))
p_conf <- ggplot2::ggplot(confusion, ggplot2::aes(Prediccion, Real, fill = n)) +
  ggplot2::geom_tile(colour = "white", linewidth = 1) +
  ggplot2::geom_text(ggplot2::aes(label = Texto), size = 3.8) +
  ggplot2::scale_fill_gradient(low = "#EDF4F7", high = "#87BBD4", guide = "none") +
  ggplot2::labs(title = paste0("Umbral OOF = ", fmt_num(threshold, 3)), x = "Clasificación", y = "Resultado observado")
p_eval <- (p_roc | p_ks | p_conf) + patchwork::plot_layout(widths = c(1, 1, 1.1))
save_fig(p_eval, "M04_discriminacion_confusion",
  paste0("El umbral OOF detecta ", fmt_pct(sensitivity), " de los incumplimientos de prueba"),
  paste0("Prueba n = ", length(y_test), ". La precisión es ", fmt_pct(precision),
    "; Youden pondera sensibilidad y especificidad por igual, no los costos monetarios."), width = 10.5, height = 4.2)
save_tab(confusion[, c("Real", "Prediccion", "n", "Etiqueta")], "M12_matriz_confusion",
  "La clasificación prioriza sensibilidad con un umbral aprendido fuera de prueba",
  paste0("Umbral ", fmt_num(threshold, 4), "; falsos positivos y negativos deben valorarse con costos de negocio."))

# Deciles descendentes de riesgo y ganancias acumuladas en prueba.
deciles <- data.frame(y = y_test, p = pred_test) |>
  dplyr::mutate(decil = dplyr::ntile(-p, 10)) |>
  dplyr::group_by(decil) |>
  dplyr::summarise(n = dplyr::n(), incumplidores = sum(y), tasa = mean(y),
    PD_media = mean(p), .groups = "drop") |>
  dplyr::mutate(clientes_acumulados = cumsum(n) / sum(n),
    captura_acumulada = cumsum(incumplidores) / sum(incumplidores),
    lift = tasa / mean(y_test), lift_acumulado = captura_acumulada / clientes_acumulados)
top_capture <- deciles$captura_acumulada[1]
save_tab(deciles, "M13_deciles_riesgo",
  paste0("El decil de mayor riesgo concentra ", fmt_pct(top_capture), " de los incumplimientos"),
  "Decil 1 = mayor riesgo. Ganancia es captura acumulada; lift es tasa del decil / tasa global de prueba.")
gain_df <- rbind(data.frame(clientes_acumulados = 0, captura_acumulada = 0),
  as.data.frame(deciles[, c("clientes_acumulados", "captura_acumulada")]))
p_gain <- ggplot2::ggplot(gain_df, ggplot2::aes(clientes_acumulados, captura_acumulada)) +
  ggplot2::geom_abline(linetype = 2, colour = "grey60") +
  ggplot2::geom_line(colour = "#356A8A", linewidth = .8) + ggplot2::geom_point(colour = "#356A8A") +
  ggplot2::scale_x_continuous(labels = scales::label_percent()) +
  ggplot2::scale_y_continuous(labels = scales::label_percent()) +
  ggplot2::labs(title = paste0("Primer decil: ", fmt_pct(top_capture), " de eventos"),
    x = "Clientes revisados, de mayor a menor riesgo", y = "Incumplimientos capturados")
p_lift <- ggplot2::ggplot(deciles, ggplot2::aes(factor(decil), lift)) +
  ggplot2::geom_col(fill = "#356A8A", width = .7) +
  ggplot2::geom_hline(yintercept = 1, linetype = 2, colour = "grey50") +
  ggplot2::labs(title = paste0("Lift del primer decil: ", fmt_num(deciles$lift[1]), "×"),
    x = "Decil de riesgo (1 = mayor)", y = "Tasa del decil / tasa de prueba")
p_cal <- ggplot2::ggplot(hl$table, ggplot2::aes(probabilidad, tasa)) +
  ggplot2::geom_abline(linetype = 2, colour = "grey50") +
  ggplot2::geom_line(colour = "#356A8A") + ggplot2::geom_point(colour = "#356A8A", size = 2) +
  ggplot2::scale_x_continuous(labels = scales::label_percent()) +
  ggplot2::scale_y_continuous(labels = scales::label_percent()) +
  ggplot2::labs(title = paste0("Brier = ", fmt_num(brier, 4)),
    subtitle = paste0("Pendiente de calibración: ", fmt_num(cal_slope)),
    x = "Probabilidad media estimada", y = "Tasa observada por decil")
p_gaincal <- (p_gain | p_lift | p_cal)
save_fig(p_gaincal, "M05_ganancia_calibracion",
  "El ordenamiento permite priorizar revisiones; la calibración requiere vigilancia",
  paste0("Prueba n = ", length(y_test), ". La diagonal representa azar en ganancia y ajuste ideal en calibración."),
  width = 10.5, height = 4.2)

# Diagnósticos de influencia: se muestran todos los casos, sin ocultar extremos.
inf_df <- data.frame(indice = seq_len(nrow(train)), Cook = cook, leverage = leverage, Residuo = std_resid)
p_cook <- ggplot2::ggplot(inf_df, ggplot2::aes(indice, Cook)) +
  ggplot2::geom_point(size = .35, alpha = .35, colour = "#356A8A") +
  ggplot2::geom_hline(yintercept = cook_cut, colour = "#B4473D", linetype = 2) +
  ggplot2::scale_y_continuous(trans = "log1p") +
  ggplot2::labs(title = paste0(length(influential), " casos superan 4/n"), x = "Registro de entrenamiento", y = "Distancia de Cook (escala log1p)")
p_lev <- ggplot2::ggplot(inf_df, ggplot2::aes(leverage, Residuo)) +
  ggplot2::geom_point(size = .35, alpha = .3, colour = "#356A8A") +
  ggplot2::geom_hline(yintercept = c(-3, 3), linetype = 2, colour = "#B4473D") +
  ggplot2::geom_vline(xintercept = leverage_cut, linetype = 2, colour = "grey50") +
  ggplot2::labs(title = "Influencia no equivale a error de registro", x = "Leverage", y = "Residuo de desvío estandarizado")
save_fig(p_cook | p_lev, "M06_influencia",
  "Excluir casos influyentes puede retirar una parte sustancial de la clase minoritaria",
  paste0("Entrenamiento n = ", nrow(train), ". La sensibilidad retira Cook > 4/n sólo para comprobar estabilidad; se conserva el modelo principal."),
  width = 9, height = 4.3)

# La tabla distingue evidencia disponible de supuestos imposibles de verificar.
assumptions <- data.frame(
  Supuesto = c("Respuesta binaria", "Independencia", "Linealidad del logit", "Multicolinealidad",
    "Observaciones influyentes", "Tamaño muestral", "Separación completa", "Bondad de ajuste/calibración"),
  Prueba = c("Frecuencias 0/1", "Duplicados completos e identificación de clientes", "Box–Tidwell + logits empíricos",
    "VIF lineal y GVIF flexible", "Cook, leverage y residuos; reestimación", "Eventos por parámetro (EPV)",
    "Convergencia, coeficientes y errores estándar", "H–L, Brier, pendiente e intercepto"),
  Resultado = c(paste0("Entrenamiento: ", sum(train$incumplimiento), " eventos / ", nrow(train)),
    "Duplicados exactos eliminados; no hay identificador de cliente verificable.",
    paste0("LRT Box–Tidwell p ", ifelse(bt_global_p < .001, "< 0,001", paste0("= ", fmt_num(bt_global_p, 3)))),
    paste0("Máximo VIF limpio: ", fmt_num(max(vif_clean$VIF)),
      "; máximo GVIF ajustado final: ", fmt_num(max(vif_final$GVIF_ajustado))),
    paste0(length(influential), " casos Cook > 4/n; diferencia media PD en sensibilidad ", fmt_num(sensitivity_mae, 4)),
    paste0(fmt_num(epv, 1), " eventos por parámetro; ", n_parameters, " parámetros sin intercepto"),
    paste0(separation_note, ifelse(is.na(formal_separation), " Sin prueba formal de separación.",
      paste0(" Separación formal detectada: ", formal_separation))),
    paste0("H–L p ", ifelse(hl$p < .001, "< 0,001", paste0("= ", fmt_num(hl$p, 3))),
      "; Brier ", fmt_num(brier, 4), "; pendiente ", fmt_num(cal_slope))),
  Decision = c("glm binomial/logit apropiado para la escala de respuesta.",
    "Independencia asumida, no demostrada; validar con ID y fechas antes de aplicación.",
    paste0("Se comparan transformaciones y splines; se selecciona ", tolower(chosen_name), " por AIC de entrenamiento."),
    "96/98 depurados; ingreso y ausencia aportan dimensiones distintas. Se conserva bandera pese a VIF elevado; OR condicional potencialmente inestable, sin declarar supuesto cumplido.",
    "Conservar observaciones válidas; documentar sensibilidad y fragilidad de asociaciones.",
    "EPV supera guía histórica de 10; no garantiza transportabilidad ni calibración.",
    "No se observan señales numéricas extremas; esto no demuestra ausencia de separación.",
    "H–L convencional exploratorio en prueba; revisar curva y Brier. Validar temporalmente; no ajustar usando prueba."))
save_tab(assumptions, "M14_supuestos", "Los supuestos se diagnostican y sus limitaciones se documentan",
  "La regresión logística no exige normalidad de predictores ni homocedasticidad de residuos.")
global_tests <- data.frame(Prueba = c("Razón de verosimilitud: final vs. nulo", "Box–Tidwell conjunto"),
  Estadistico = c(lrt_stat, bt_lrt$Deviance[2]), gl = c(lrt_df, bt_lrt$Df[2]), p = c(lrt_p, bt_global_p))
save_tab(global_tests, "M15_significancia_global", "El modelo aporta información sobre el incumplimiento frente al intercepto solo",
  "Pruebas sobre entrenamiento. Significancia estadística no mide utilidad económica ni causalidad.")

# Salidas técnicas y objeto compacto permiten auditar las cifras del informe.
capture.output(lapply(fits, summary), file = "anexos/modelos_summary.txt")
capture.output(summary(fit_sensitivity), file = "anexos/modelo_sensibilidad_summary.txt")
capture.output(summary(fit_top10), file = "anexos/modelo_sensibilidad_top10_summary.txt")
capture.output(summary(bt_fit), file = "anexos/box_tidwell_summary.txt")
write.csv(data.frame(fold = fold_id, y = train_raw$incumplimiento, pd_oof = oof),
  "anexos/predicciones_oof.csv", row.names = FALSE)
write.csv(data.frame(y = y_test, pd = pred_test, clase = class_test),
  "anexos/predicciones_prueba.csv", row.names = FALSE)
model_results <- list(chosen = chosen_name, selected_model = chosen_name, threshold = threshold, comparison = comparison,
  metrics = metrics, auc = auc_test, auc_ci = auc_ci, auc_low = auc_ci[1], auc_high = auc_ci[3],
  gini = gini_test, ks = ks_test,
  sensitivity = sensitivity, specificity = specificity, precision = precision, f1 = f1,
  accuracy = accuracy, brier = brier, calibration_intercept = cal_intercept,
  calibration_slope = cal_slope, confusion = confusion, deciles = deciles,
  top_capture = top_capture, top_decile_capture = top_capture, or_linear = or_linear,
  or_contrasts = or_contrasts, contrasts = or_contrasts,
  effects = effects, bt_table = bt_table, bt_p = bt_global_p, vif = vif_table,
  vif_final = vif_final, hl = hl, epv = epv, influence = influence_table,
  influence_event_share = sensitivity_event_share, sensitivity_mae = sensitivity_mae,
  sensitivity_estimable_n = sum(sensitivity_estimable),
  sensitivity_contrasts = sensitivity_contrasts, top10_contrasts = top10_contrasts,
  top10_mae = top10_mae, assumptions = assumptions,
  global_tests = global_tests, formal_separation = formal_separation)
saveRDS(model_results, "anexos/model_results.rds")
saveRDS(list(formula = chosen_formula, model = fit_final, threshold = threshold, preprocessing = prep,
  description = "Requiere aplicar los parámetros de preparación ajustados en entrenamiento."),
  "anexos/modelo_final.rds")
saveRDS(list(figures = figure_registry, tables = table_registry), "anexos/registro_modelo.rds")
