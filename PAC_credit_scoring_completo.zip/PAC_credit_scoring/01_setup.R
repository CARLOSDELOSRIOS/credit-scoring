# Instala únicamente dependencias ausentes y configura la reproducción en RStudio.
required <- c('rmarkdown','knitr','ggplot2','dplyr','tidyr','scales','patchwork',
              'officer','flextable','pROC','car','broom','nortest','jsonlite')
missing_pkgs <- required[!vapply(required, requireNamespace, logical(1), quietly = TRUE)]
if (length(missing_pkgs)) install.packages(missing_pkgs, repos='https://cloud.r-project.org')
invisible(lapply(required, library, character.only=TRUE))
set.seed(2026)
options(scipen=999, stringsAsFactors=FALSE, OutDec=',')
knitr::opts_chunk$set(echo=FALSE,message=FALSE,warning=FALSE,fig.width=7,fig.height=4.5,dpi=300)
for (folder in c('figuras','tablas','anexos')) dir.create(folder, showWarnings=FALSE)
pal <- c('No incumplió'='#356A8A','Incumplió'='#B4473D')
source_note <- 'Fuente: Kaggle (2011), Give Me Some Credit. Elaboración propia en R.'
ggplot2::theme_set(ggplot2::theme_minimal(base_size=12, base_family='sans') +
  ggplot2::theme(plot.title=element_text(face='bold',size=13,color='#19394D'),
    plot.subtitle=element_text(size=10),plot.caption=element_text(size=8,hjust=0),
    panel.grid.minor=element_blank(),legend.position='bottom',
    plot.title.position='plot',plot.caption.position='plot'))
fmt_num <- function(x,digits=2) formatC(x,format='f',digits=digits,big.mark=' ',decimal.mark=',')
fmt_pct <- function(x,digits=1) paste0(fmt_num(100*x,digits),' %')
fmt_p <- function(x) ifelse(is.na(x),'—',ifelse(x<0.001,'< 0,001',fmt_num(x,3)))
figure_registry <- list(); table_registry <- list()
flextable::set_flextable_defaults(font.family='Calibri',font.size=9,padding=3,
 line_spacing=1,decimal.mark=',',big.mark=' ',table.layout='fixed')

# Fija anchos reales en Word: evita que el autoajuste expanda tablas fuera de la página.
table_widths <- function(df,total=6.6) {
  weights <- vapply(seq_along(df),function(j) {
    vals <- as.character(df[[j]])
    lens <- nchar(c(names(df)[j],vals[!is.na(vals)]))
    max(8,min(40,if(length(lens)) max(lens) else 8))
  },numeric(1))
  total*weights/sum(weights)
}

# Registra el título, la fuente y la lectura de cada figura y exporta a 300 dpi.
save_fig <- function(p,id,title,note,width=7,height=4.5) {
  raw_title <- title
  title <- paste(strwrap(title,width=floor(width*10)),collapse='\n')
  caption <- paste(source_note,paste(strwrap(paste('Nota.',note),width=floor(width*15)),collapse='\n'),sep='\n')
  if (inherits(p,'patchwork')) {
    p <- p + patchwork::plot_annotation(title=title,caption=caption,
      theme=theme(plot.title=element_text(face='bold',size=13,color='#19394D'),
                  plot.caption=element_text(size=8,hjust=0),plot.title.position='plot',plot.caption.position='plot'))
  } else p <- p + labs(title=title,caption=caption)
  ggplot2::ggsave(file.path('figuras',paste0(id,'.png')),p,width=width,height=height,dpi=300,bg='white',limitsize=FALSE)
  figure_registry[[id]] <<- list(id=id,title=raw_title,note=note,width=width,height=height)
  invisible(p)
}

# Exporta tablas editables a Word y su contenido numérico a CSV.
save_tab <- function(df,id,title,note) {
  df <- as.data.frame(df)
  write.csv(df,file.path('tablas',paste0(id,'.csv')),row.names=FALSE,na='',fileEncoding='UTF-8')
  ft <- flextable::flextable(df) |> flextable::theme_booktabs() |>
    flextable::font(fontname='Calibri',part='all') |> flextable::fontsize(size=9,part='all') |>
    flextable::bold(part='header') |> flextable::color(color='#19394D',part='header') |>
    flextable::autofit() |> flextable::fit_to_width(max_width=6.6)
  for (nm in names(df)[vapply(df,is.numeric,logical(1))]) {
    digits <- if (all(is.na(df[[nm]]) | df[[nm]]==round(df[[nm]]))) 0 else if (grepl('OR|IC95',nm)) 2 else 3
    ft <- flextable::colformat_double(ft,j=nm,digits=digits,decimal.mark=',',big.mark=' ',na_str='—')
  }
  pcols <- names(df)[grepl('^p($|[ ._])',names(df),ignore.case=TRUE)]
  for (nm in pcols) {
    if (is.numeric(df[[nm]])) {
      ft <- flextable::set_formatter(ft,values=setNames(list(fmt_p),nm))
      sig <- which(!is.na(df[[nm]]) & df[[nm]] < .05)
    } else sig <- which(grepl('^<',df[[nm]]))
    if (length(sig)) ft <- flextable::bold(flextable::color(ft,i=sig,j=nm,color='#356A8A'),i=sig,j=nm)
  }
  ft <- flextable::add_header_lines(ft,values=title)
  ft <- flextable::add_footer_lines(ft,values=c(paste('Nota.',note),source_note))
  ft <- flextable::width(ft,width=table_widths(df))
  ft <- flextable::padding(ft,padding=3,part='all')
  ft <- flextable::set_table_properties(ft,layout='fixed')
  doc <- officer::read_docx() |>
    officer::body_set_default_section(officer::prop_section(
      page_size=officer::page_size(width=8.27,height=11.69),
      page_margins=officer::page_mar(top=.7,bottom=.7,left=.7,right=.7,gutter=0))) |>
    flextable::body_add_flextable(value=ft)
  print(doc,target=file.path('tablas',paste0(id,'.docx')))
  table_registry[[id]] <<- list(id=id,title=title,note=note,data=df)
  invisible(ft)
}

# Presenta tablas compactas dentro del informe manteniendo la exportación completa.
report_table <- function(df,size=8) {
  df <- as.data.frame(df)
  ft <- flextable::flextable(df) |> flextable::theme_booktabs() |>
    flextable::fontsize(size=size,part='all') |> flextable::bold(part='header') |>
    flextable::color(color='#19394D',part='header') |>
    flextable::padding(padding=3,part='all') |>
    flextable::width(width=table_widths(df)) |>
    flextable::set_table_properties(layout='fixed')
  for (nm in names(df)[vapply(df,is.numeric,logical(1))]) {
    digits <- if(all(is.na(df[[nm]])|df[[nm]]==round(df[[nm]]))) 0 else 3
    ft <- flextable::colformat_double(ft,j=nm,digits=digits,decimal.mark=',',big.mark=' ',na_str='—')
  }
  for(nm in names(df)[grepl('^p($|[ ._])',names(df),ignore.case=TRUE)]) {
    val <- suppressWarnings(as.numeric(gsub(',','.',as.character(df[[nm]]),fixed=TRUE)))
    sig <- which(grepl('^<',as.character(df[[nm]])) | (!is.na(val) & val<.05))
    if(length(sig)) ft <- flextable::bold(flextable::color(ft,i=sig,j=nm,color='#356A8A'),i=sig,j=nm)
  }
  ft
}
