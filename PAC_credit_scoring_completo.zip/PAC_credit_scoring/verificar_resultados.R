# Verifica consistencia cruzada entre predicciones, métricas y archivos exportados.
m <- readRDS('anexos/model_results.rds')
e <- readRDS('anexos/eda_results.rds')
p <- readRDS('anexos/preparacion_results.rds')
r <- readRDS('anexos/registro_completo.rds')
pred <- read.csv('anexos/predicciones_prueba.csv')
oof <- read.csv('anexos/predicciones_oof.csv')
stopifnot(p$raw_n==150000,p$clean_n==149390,
 nrow(pred)==44818,nrow(oof)==104572,
 sum(pred$y)==3003,sum(oof$y)==7006,
 all(is.finite(pred$pd)),all(pred$pd>=0 & pred$pd<=1),
 all(is.finite(oof$pd_oof)),all(pred$clase==as.integer(pred$pd>=m$threshold)))
tp <- sum(pred$clase==1 & pred$y==1);fp<-sum(pred$clase==1 & pred$y==0)
tn <- sum(pred$clase==0 & pred$y==0);fn<-sum(pred$clase==0 & pred$y==1)
stopifnot(isTRUE(all.equal(tp/(tp+fn),m$sensitivity)),
 isTRUE(all.equal(tn/(tn+fp),m$specificity)),
 isTRUE(all.equal(tp/(tp+fp),m$precision)),
 isTRUE(all.equal(mean((pred$pd-pred$y)^2),m$brier)),
 isTRUE(all.equal(2*m$auc-1,m$gini)),
 sum(m$deciles$n)==nrow(pred),sum(m$deciles$incumplidores)==sum(pred$y),
 abs(tail(m$deciles$captura_acumulada,1)-1)<1e-10,
 all(diff(m$deciles$captura_acumulada)>=0),
 isTRUE(all.equal(p.adjust(e$inference_raw$p,'BH'),e$inference_raw$p_bh)))
stopifnot(all(file.exists(file.path('figuras',paste0(names(r$figures),'.png')))),
 all(file.exists(file.path('tablas',paste0(names(r$tables),'.csv')))),
 all(file.exists(file.path('tablas',paste0(names(r$tables),'.docx')))))
# Comprueba sintaxis del código extraído sin volver a ajustar modelos.
tmpcode <- tempfile(fileext='.R')
params <- list(usar_resultados_guardados=FALSE)
invisible(knitr::purl('PAC_credit_scoring.Rmd',output=tmpcode,quiet=TRUE))
invisible(parse(tmpcode,encoding='UTF-8'));unlink(tmpcode)
msg <- c('VERIFICACIÓN FINAL: CORRECTA',
 'El Rmd completo se ejecutó desde el CSV; R 4.5.0. No se utilizaron resultados simulados.',
 'Recuento de filas y clases consistente entre limpieza, partición y predicciones.',
 'Clases coherentes con umbral OOF prefijado; métricas recalculadas desde predicciones coinciden.',
 'Gini, Brier y deciles coherentes; captura acumulada final = 100%.',
 'Ajuste BH conjunto sobre los 21 contrastes verificado.',
 paste(length(r$figures),'figuras PNG y',length(r$tables),'tablas con CSV y Word presentes.'),
 'Código extraído del Rmd parsea sin errores.',
 paste('Matriz de prueba: VN',tn,'FP',fp,'FN',fn,'VP',tp),
 'El Word se convirtió a PDF para verificar 15 páginas y revisar legibilidad. Anexos separados.',
 'Pendientes administrativos: nombres de integrantes y docente.')
writeLines(msg,'anexos/verificacion_final.txt',useBytes=TRUE)
cat(paste(msg,collapse='\n'),'\n')
