# Ejecutar desde la raíz del proyecto abierto en RStudio.
# Instala dependencias ausentes; la primera instalación requiere conexión a CRAN.
if(!file.exists('datos/cs-training.csv')) stop('Abra Credit_scoring.Rproj desde la carpeta extraída.')
source('01_setup.R')
if(!file.exists('referencia.docx')) source('crear_plantilla.R')

# Recalcula desde el CSV: preparación, exploración, modelos, OOF y evaluación.
rmarkdown::render('PAC_credit_scoring.Rmd',params=list(usar_resultados_guardados=FALSE),
 output_file='Informe_credit_scoring.docx',envir=new.env(parent=globalenv()))

# Los documentos auxiliares leen exclusivamente los resultados ya calculados.
for(file in c('Guion_exposicion.Rmd','Anexos_tecnicos.Rmd','Anexo_codigo.Rmd')) {
 rmarkdown::render(file,envir=new.env(parent=globalenv()))
}
message('Entrega regenerada. Revise los nombres de portada y la paginación en su instalación de Word.')
