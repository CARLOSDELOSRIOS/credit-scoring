# Ensambla un R Markdown autónomo que contiene todos los cálculos y la narrativa.
yaml <- c('---','lang: es-PE','output:', '  word_document:',
 '    reference_docx: referencia.docx','    toc: false','params:',
 '  usar_resultados_guardados: false','---','')
chunk <- function(file,label,options='include=FALSE') {
 c(paste0('```{r ',label,', ',options,'}'),readLines(file,warn=FALSE,encoding='UTF-8'),'```','')
}
# Convierte tablas editoriales a flextable para conservar columnas al abrir Word.
pipe_tables_to_r <- function(lines,prefix) {
  starts <- which(grepl('^\\|',lines) & !c(FALSE,head(grepl('^\\|',lines),-1)))
  for(k in rev(seq_along(starts))) {
    first <- starts[k];last <- first
    while(last<length(lines) && grepl('^\\|',lines[last+1])) last<-last+1
    rows <- lines[first:last]
    cells <- lapply(rows[-2],function(x) trimws(strsplit(sub('\\|$','',sub('^\\|','',x)),'\\|')[[1]]))
    df <- as.data.frame(do.call(rbind,cells[-1]),stringsAsFactors=FALSE)
    names(df)<-cells[[1]]
    replacement <- c(paste0('```{r ',prefix,'-',k,'}'),
      '# Presenta la tabla con anchos fijos para asegurar lectura en Word.',
      'tabla_editorial <-',capture.output(dput(df)),'report_table(tabla_editorial,8)','```','')
    lines <- c(if(first>1)lines[seq_len(first-1)],replacement,
      if(last<length(lines))lines[seq.int(last+1,length(lines))])
  }
  lines
}
body <- readLines('cuerpo_informe.Rmd',warn=FALSE,encoding='UTF-8')
# Números literales conservan objetivos y conclusiones visibles en distintas versiones de Word.
ii <- grep('^[1-6]\\. ',body)
body[ii] <- paste0(sub('^([1-6])\\. ','**\\1.** ',body[ii]),'\n')
theory <- readLines('marco_teorico.Rmd',warn=FALSE,encoding='UTF-8')
theory[1] <- '# 2. Marco teórico'
refs <- readLines('referencias.Rmd',warn=FALSE,encoding='UTF-8')
refs <- refs[seq_len(which(refs=='<!-- FIN_REFERENCIAS_APA -->')-1)]
refs[1] <- '# Referencias'
refs <- c(refs[1],'','::: {custom-style="APA References"}',refs[-1],':::')
insert <- function(x,marker,value) {i<-which(x==marker);c(x[seq_len(i-1)],value,x[seq.int(i+1,length(x))])}
body <- insert(body,'<!-- MARCO_TEORICO -->',theory)
i <- which(body=='<!-- REFERENCIAS -->');body <- c(body[seq_len(i-1)],refs)
full <- c(yaml,chunk('01_setup.R','configuracion-paquetes-y-exportaciones'),
 chunk('02_preparacion.R','diagnostico-limpieza-y-particion','include=FALSE, eval=!params$usar_resultados_guardados'),
 chunk('03_eda.R','descriptiva-e-inferencia','include=FALSE, eval=!params$usar_resultados_guardados'),
 chunk('04_model.R','regresion-diagnosticos-y-validacion','include=FALSE, eval=!params$usar_resultados_guardados'),
 chunk('05_sintesis.R','sintesis-y-exportaciones'),body)
writeLines(full,'PAC_credit_scoring.Rmd',useBytes=TRUE)

# El guion reutiliza resultados calculados y distribuye exactamente quince minutos.
guion <- c(yaml[seq_len(7)],'---','',
 '# Guion de exposición · 15 minutos','',
 'Curso: Introducción a los Modelos Estadísticos. Equipo de cuatro integrantes; sustituir A–D por los nombres. Nueve diapositivas, una idea central por diapositiva. No se requiere mostrar código durante la exposición.','',
 '```{r datos-guion, include=FALSE}',
 '# Recupera resultados ejecutados para evitar cifras escritas a mano.',
 'source("01_setup.R");source("05_sintesis.R")','```','',
 '## Distribución de tiempo','',
 '| Diapositiva | Tema | Integrante | Intervalo | Figura sugerida |',
 '|---|---|---|---|---|',
 '| 1 | Pregunta y alcance | A | 0:00–1:00 | Portada |',
 '| 2 | Datos y desbalance | A | 1:00–2:30 | e01_desbalance |',
 '| 3 | Protocolo sin fuga | A | 2:30–3:45 | f03_flujo |',
 '| 4 | Calidad e indicadores | B | 3:45–5:30 | f01_faltantes / f02_extremos |',
 '| 5 | Perfiles y asociaciones | B | 5:30–7:30 | e06_panel_hallazgos / P01_efectos_resumen |',
 '| 6 | Modelo e interpretación | C | 7:30–9:30 | P02_or_resumen / M02_probabilidades_ajustadas |',
 '| 7 | Supuestos y límites | C | 9:30–11:15 | M03_logit_empirico / M06_influencia |',
 '| 8 | Desempeño reservado | D | 11:15–13:15 | M04_discriminacion_confusion |',
 '| 9 | Prioridad y recomendaciones | D | 13:15–15:00 | M05_ganancia_calibracion |','',
 'Cada integrante dispone de 3 minutos y 45 segundos. Las preguntas se responden después de los 15 minutos.','',
 '## Notas del orador','',
 '### 1. Qué queremos responder','',
 '«Estudiamos qué características se asocian con morosidad grave en los dos años siguientes. Queremos explicar patrones y comprobar su capacidad predictiva. La fuente es Give Me Some Credit; el alcance es académico. Una asociación no demuestra que modificar una característica cause un cambio de riesgo». Señalar la pregunta y los seis objetivos agrupados en calidad, asociación y validación.','',
 '### 2. Por qué la exactitud no basta','',
 '«La base original contiene 150 000 registros y 10 026 incumplimientos. La clase positiva es minoritaria. Un clasificador que nunca alerte tendría alta exactitud y sensibilidad cero. Necesitamos medir AUC, sensibilidad, especificidad, precisión y calibración». Mostrar proporciones y denominador, sin presentar 2011 como fecha individual de observación.','',
 '### 3. Cómo protegimos la prueba','',
 '«Después de retirar copias exactas y una edad inválida, quedan 149 390 registros. Reservamos el 30 % por clase. Imputación, topes y modelo se aprenden en entrenamiento; el umbral usa predicciones fuera de pliegue. La muestra de prueba no decide ni la fórmula ni el umbral». Aclarar que la selección de fórmula por AIC no está anidada en la OOF y que la evaluación central es prueba.','',
 '### 4. Qué hicimos con los problemas de datos','',
 '«El ingreso tiene 29 731 faltantes. No los confundimos con cero: imputamos y conservamos una bandera. Los códigos 96/98 se tratan como anómalos, sin inventar su significado. La utilización y la deuda se topan con percentiles de entrenamiento. Los indicadores conservan los tramos originales». Mencionar que alguna_vez_90 separa la categoría especial en el análisis descriptivo.','',
 '### 5. Qué muestran los perfiles','',
 '«En entrenamiento, la tasa pasa de 2,2 % con utilización baja a 37,5 % en sobregiro. También hay diferencias por historial y edad. Las 21 comparaciones resultan significativas tras BH, pero las magnitudes son distintas: la utilización alcanza delta de Cliff 0,554, mientras el ratio de deuda tiene una diferencia de rangos pequeña». Explicar que Cliff y V de Cramér no comparten escala ni miden causalidad.','',
 '### 6. Cómo interpretamos la regresión','',
 '«Comparamos modelos completo, reducido y flexible. El AIC de entrenamiento favorece el flexible. La utilización de 10 % a 90 % tiene OR `r fmt_num(m$contrasts$OR[1])`; pasar de cero a un atraso 90+ tiene OR `r fmt_num(m$contrasts$OR[5])`, con otras variables fijas. Son cambios de odds, no aumentos equivalentes de probabilidad». Mostrar una curva para hacer visible la no linealidad.','',
 '### 7. Qué supuestos pudimos verificar','',
 '«La respuesta es binaria y hay suficientes eventos por parámetro. Box–Tidwell señala curvatura, por eso usamos splines. Persisten colinealidad e incertidumbre sobre independencia. Cook > 4/n marca muchos eventos; excluirlos sesgaría la composición. La sensibilidad con los diez mayores Cook produce cambios pequeños en los contrastes centrales. No afirmamos que todos los supuestos estén demostrados».','',
 '### 8. Qué pasa en datos reservados','',
 '«En prueba, el AUC es `r fmt_num(m$auc,3)`, con IC 95 % `r fmt_num(m$auc_ci[1],3)`–`r fmt_num(m$auc_ci[3],3)`. El umbral `r fmt_num(m$threshold,4)` detecta `r fmt_pct(m$sensitivity)` de los incumplimientos, pero solo `r fmt_pct(m$precision)` de las alertas corresponde a eventos. Hay 8 963 falsos positivos y 695 falsos negativos. El umbral real dependería de los costos y la capacidad de revisión».','',
 '### 9. Qué concluimos y recomendamos','',
 '«El decil superior concentra `r fmt_pct(m$top_decile_capture)` de los eventos; sirve para estudiar priorización, no para justificar rechazos automáticos. Recomendamos mejorar calidad, validar temporalmente y en población peruana, revisar calibración y elegir umbral con costos. La conclusión responde al problema; no es repetir cada cifra». Terminar con la acción: piloto de revisión humana con monitoreo de desempeño, estabilidad y equidad.','',
 '## Cinco preguntas probables del docente','',
 '**1. ¿Por qué no usaron 0,5?** El desbalance y el intercambio entre errores vuelven insuficiente una elección automática. Se prefijó Youden mediante predicciones OOF de entrenamiento; no es un óptimo económico. Los costos podrían justificar otro umbral.','',
 '**2. ¿Cómo verificaron la linealidad del logit?** Usamos Box–Tidwell sobre escalas especificadas y logits empíricos por deciles. El contraste conjunto rechaza la forma lineal; comparamos una logística con splines, cuya selección se basó en AIC de entrenamiento. El gráfico marginal no certifica ajuste condicional.','',
 '**3. ¿Qué hicieron con 96 y 98?** Se consideran anómalos por su patrón extremo y coincidencia. Se recodifican como NA, se imputan con la mediana de entrenamiento y se conserva codigo_especial. No sabemos su significado administrativo; la descripción separa esos registros de los historiales sin atrasos.','',
 '**4. ¿Un AUC alto demuestra buen modelo?** No. AUC mide ordenación; la calibración, el Brier, los errores, la estabilidad, los costos y las condiciones de uso son distintos. H–L detecta discrepancias y persiste colinealidad: el modelo necesita validación adicional.','',
 '**5. ¿Conclusión e interpretación son lo mismo?** No. Una interpretación explica una OR, una tasa o un IC. Una conclusión responde a un objetivo y al problema; por ejemplo, conservar calidad e historial en la evaluación y recomendar validación externa antes de uso. No declara causalidad ni repite cifras sin propósito.','',
 '## Lista de verificación previa a presentar','',
 '- Completar nombres y docente; ensayar con cronómetro y transiciones A→B→C→D.',
 '- Usar la versión final de figuras exportadas, con unidades y fuente.',
 '- Mantener fijos denominadores: original 150 000, depurada 149 390, entrenamiento 104 572, prueba 44 818.',
 '- Diferenciar odds, probabilidad, AUC, precisión y sensibilidad.',
 '- Reconocer límites de independencia, codificación, colinealidad y calibración.'
 )
guion <- pipe_tables_to_r(guion,'distribucion-tiempo')
writeLines(guion,'Guion_exposicion.Rmd',useBytes=TRUE)

# Anexo técnico: incorpora cada figura con interpretación y cada tabla con una nota de lectura.
regs <- lapply(c('anexos/registro_eda.rds','anexos/registro_modelo.rds','anexos/registro_sintesis.rds'),readRDS)
fr <- list();tr <- list()
for (reg in regs) {fr[names(reg$figures)]<-reg$figures;tr[names(reg$tables)]<-reg$tables}
saveRDS(list(figures=fr,tables=tr),'anexos/registro_completo.rds')
a <- c(yaml[seq_len(7)],'---','','# Anexos técnicos','','Código y resultados del PAC de credit scoring. El cuerpo principal se entrega por separado. Estos anexos contienen las salidas completas y sus límites de lectura.','',
 '```{r configuracion-anexos, include=FALSE}','# Carga funciones de presentación y resultados ejecutados.',
 'source("01_setup.R");source("05_sintesis.R")','reg <- readRDS("anexos/registro_completo.rds")','```','',
 '## A. Diccionario, protocolo y comprobación de entrega','',
 'El código completo y ejecutable está en PAC_credit_scoring.Rmd y se reproduce íntegramente en Anexo_codigo.docx. Los archivos R numerados facilitan revisión modular; el .Rmd contiene esos mismos bloques y no depende de ellos para recalcular.','',
 'No se calculan los opcionales WoE/IV ni scorecard: se prioriza el análisis obligatorio. La imputación es simple y los IC son condicionales. La tabla de trazabilidad y el archivo MD5 identifican los datos; sessionInfo registra las versiones.','',
 '```{r diccionario-anexo}','# Presenta definiciones y unidades de todos los indicadores.',
 'report_table(dictionary,8)','```','',
 '## B. Figuras completas','')
idx <- 0
for (id in names(fr)) {
 idx<-idx+1;z<-fr[[id]]
 interp <- if(id %in% names(e$interpretations)) e$interpretations[[id]] else z$note
 a<-c(a,'\\newpage','',paste0('### Figura A',idx,'. ',z$title),'',
  paste0('```{r anexo-figura-',idx,', out.width="100%"}'),
  '# Muestra la figura exportada en R, conservando fuente y lectura.',
  paste0('knitr::include_graphics("figuras/',id,'.png")'),'```','',interp,'')
}
a<-c(a,'\\newpage','','## C. Tablas completas','')
idx <- 0
for(id in names(tr)) {
 idx<-idx+1;z<-tr[[id]]
 a<-c(a,paste0('### Tabla A',idx,'. ',z$title),'',
  paste0('```{r anexo-tabla-',idx,'}'),'# Conserva todos los resultados y notas de la tabla exportada.',
  paste0('report_table(reg$tables[["',id,'"]]$data,7.5)'),'```','',paste('Nota de lectura.',z$note),
  'Fuente: Kaggle (2011). Elaboración propia en R.','')
}
a<-c(a,'\\newpage','','## D. Salidas técnicas','')
for(file in c('modelos_summary.txt','modelo_sensibilidad_summary.txt','box_tidwell_summary.txt','sessionInfo.txt')) {
 a<-c(a,paste('###',file),'',paste0('```{r ',gsub('[._]','-',file),', results="asis"}'),
 '# Imprime salidas originales de R para auditoría, sin resumir sus estadísticos.',
 paste0('cat("```text\\n",paste(readLines("anexos/',file,'",warn=FALSE),collapse="\\n"),"\\n```\\n",sep="")'),'```','')
}
a<-c(a,'## E. Referencias verificadas y alcance de consulta','',
 'Las referencias del cuerpo fueron contrastadas con metadatos editoriales o registros bibliográficos. La tabla verificacion_referencias.tsv incluye URL y alcance; no se afirma lectura completa de textos sujetos a suscripción.','',
 '## F. Lista de verificación de la rúbrica','',
 '| Requisito | Evidencia de entrega |', '|---|---|',
 '| Estructura y objetivos | Cuerpo del informe, apartados 1–9 |',
 '| R Markdown reproducible | PAC_credit_scoring.Rmd, semilla 2026, rutas relativas |',
 '| Calidad e indicadores | Tablas t01–t04 y P01; funciones fit_prep/apply_prep |',
 '| Descriptiva e inferencia | Figuras e01–e09, tablas e01–e05, tamaños de efecto y BH |',
 '| Modelos y supuestos | Tablas M01–M16; diagnóstico y decisiones con límites explícitos |',
 '| Evaluación reservada | AUC/IC, ROC, KS, matriz, calibración, deciles y lift |',
 '| Visuales exportados | Carpetas figuras/ (300 dpi) y tablas/ (CSV/Word) |',
 '| Interpretación y conclusiones separadas | Lectura junto a salidas y seis conclusiones vinculadas a objetivos |',
 '| APA y varios autores | Doce referencias, diez fuentes académicas; verificación adjunta |',
 '| Exposición | Guion de nueve diapositivas, quince minutos y cuatro integrantes |',
 '| Extensión | Cuerpo de quince páginas verificado en PDF; anexos separados |',
 '| Datos administrativos | Nombres de integrantes y docente pendientes de completar |',
 '| Opcionales WoE/IV y scorecard | No incluidos; se cubre el alcance obligatorio |'
 )
a <- pipe_tables_to_r(a,'verificacion-rubrica')
writeLines(a,'Anexos_tecnicos.Rmd',useBytes=TRUE)
code <- c(yaml[seq_len(6)],'---','','# Anexo de código completo','',
 'Reproducción literal del archivo PAC_credit_scoring.Rmd. Para ejecutarlo, utilizar el archivo .Rmd del proyecto en RStudio; este documento facilita su revisión.','',
 '```{r codigo-literal, echo=FALSE, results="asis"}',
 '# Inserta el texto como salida literal para que knitr no ejecute los chunks reproducidos.',
 'cat("````text\\n",paste(readLines("PAC_credit_scoring.Rmd",warn=FALSE,encoding="UTF-8"),collapse="\\n"),"\\n````\\n",sep="")',
 '```')
writeLines(code,'Anexo_codigo.Rmd',useBytes=TRUE)
