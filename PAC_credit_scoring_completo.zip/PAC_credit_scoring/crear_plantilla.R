# Construye en R una plantilla A4 compacta para el límite de quince páginas.
library(officer)
library(xml2)
ref <- read_docx()
ref <- body_set_default_section(ref,prop_section(
  page_size=page_size(width=8.27,height=11.69),
  page_margins=page_mar(top=.65,bottom=.65,left=.75,right=.75,header=.25,footer=.25,gutter=0),
  footer_default=block_list(fpar('PAC · Credit scoring   |   ',run_word_field('PAGE'),
    fp_p=fp_par(text.align='right'),fp_t=fp_text(font.size=8,color='#617482')))))
print(ref,target='referencia.docx')
tmp <- tempfile('plantilla_'); dir.create(tmp)
unzip('referencia.docx',exdir=tmp)
styles_file <- file.path(tmp,'word','styles.xml')
s <- read_xml(styles_file); ns <- xml_ns(s)
xml_remove(xml_find_all(s,'//w:style/w:pPr/w:numPr',ns))
# Modifica estilos mediante XML OOXML; todos los contenidos se generan desde R.
style_set <- function(id,size,space=70) {
  node <- xml_find_first(s,paste0('//w:style[@w:styleId="',id,'"]'),ns)
  if (inherits(node,'xml_missing')) return(invisible(NULL))
  rpr <- xml_find_first(node,'w:rPr',ns)
  if (inherits(rpr,'xml_missing')) rpr <- xml_add_child(node,'w:rPr')
  for (tag in c('sz','szCs')) {
    z <- xml_find_first(rpr,paste0('w:',tag),ns)
    if (inherits(z,'xml_missing')) z <- xml_add_child(rpr,paste0('w:',tag))
    xml_set_attr(z,'w:val',as.character(size*2))
  }
  fonts <- xml_find_first(rpr,'w:rFonts',ns)
  if (inherits(fonts,'xml_missing')) fonts <- xml_add_child(rpr,'w:rFonts')
  xml_set_attr(fonts,'w:ascii','Calibri'); xml_set_attr(fonts,'w:hAnsi','Calibri')
  ppr <- xml_find_first(node,'w:pPr',ns)
  if (inherits(ppr,'xml_missing')) ppr <- xml_add_child(node,'w:pPr')
  spacing <- xml_find_first(ppr,'w:spacing',ns)
  if (inherits(spacing,'xml_missing')) spacing <- xml_add_child(ppr,'w:spacing')
  xml_set_attr(spacing,'w:after',as.character(space));xml_set_attr(spacing,'w:line','245')
  xml_set_attr(spacing,'w:lineRule','auto')
}
for (id in c('Normal','BodyText','FirstParagraph')) style_set(id,10,80)
for (id in c('Heading1','Titre1')) style_set(id,17,130)
for (id in c('Heading2','Titre2')) style_set(id,13,100)
style_set('Caption',9,55);style_set('TableCaption',9,55);style_set('ImageCaption',9,55)
style_set('SourceCode',7,0)
# La bibliografía utiliza sangría francesa de media pulgada conforme a APA.
apa <- xml_add_child(s,xml_find_first(s,'//w:style[@w:styleId="Normal"]',ns))
xml_set_attr(apa,'w:styleId','APAReferences')
xml_set_attr(xml_find_first(apa,'w:name',ns),'w:val','APA References')
ppr <- xml_find_first(apa,'w:pPr',ns)
if(inherits(ppr,'xml_missing')) ppr <- xml_add_child(apa,'w:pPr')
ind <- xml_find_first(ppr,'w:ind',ns)
if(inherits(ind,'xml_missing')) ind <- xml_add_child(ppr,'w:ind')
xml_set_attr(ind,'w:left','720');xml_set_attr(ind,'w:hanging','720')
write_xml(s,styles_file)
dest <- normalizePath('referencia.docx'); oldwd <- getwd();setwd(tmp)
utils::zip(dest,files=list.files('.',recursive=TRUE,all.files=TRUE,no..=TRUE),flags='-q')
setwd(oldwd);unlink(tmp,recursive=TRUE)
